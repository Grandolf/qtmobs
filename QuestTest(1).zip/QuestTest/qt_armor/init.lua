--qt_armor

minetest.register_tool("qt_armor:helmet_elemental", {
	description = "Elemental Helmet",
	inventory_image = "qt_armor_inv_helmet_elemental.png",
	groups = {armor_head=16, armor_heal=10, armor_use=60},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_elemental", {
	description = "Elemental Chestplate",
	inventory_image = "qt_armor_inv_chestplate_elemental.png",
	groups = {armor_torso=21, armor_heal=10, armor_use=60},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_elemental", {
	description = "Elemental Leggings",
	inventory_image = "qt_armor_inv_leggings_elemental.png",
	groups = {armor_legs=21, armor_heal=10, armor_use=60},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_elemental", {
	description = "Elemental Boots",
	inventory_image = "qt_armor_inv_boots_elemental.png",
	groups = {armor_feet=16, armor_heal=10, armor_use=60},
	wear = 0,
})

minetest.register_tool("qt_armor:helmet_awesome", {
	description = "Awesome Helmet",
	inventory_image = "qt_armor_inv_helmet_awesome.png",
	groups = {armor_head=17, armor_heal=10, armor_use=70},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_awesome", {
	description = "Awesome Chestplate",
	inventory_image = "qt_armor_inv_chestplate_awesome.png",
	groups = {armor_torso=22, armor_heal=10, armor_use=70},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_awesome", {
	description = "Awesome Leggings",
	inventory_image = "qt_armor_inv_leggings_awesome.png",
	groups = {armor_legs=22, armor_heal=10, armor_use=70},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_awesome", {
	description = "Awesome Boots",
	inventory_image = "qt_armor_inv_boots_awesome.png",
	groups = {armor_feet=17, armor_heal=10, armor_use=70},
	wear = 0,
})

minetest.register_tool("qt_armor:helmet_netherite", {
	description = "Netherite Helmet",
	inventory_image = "qt_armor_inv_helmet_netherite.png",
	groups = {armor_head=18, armor_heal=10, armor_use=80},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_netherite", {
	description = "Netherite Chestplate",
	inventory_image = "qt_armor_inv_chestplate_netherite.png",
	groups = {armor_torso=23, armor_heal=10, armor_use=80},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_netherite", {
	description = "Netherite Leggings",
	inventory_image = "qt_armor_inv_leggings_netherite.png",
	groups = {armor_legs=23, armor_heal=10, armor_use=80},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_netherite", {
	description = "Netherite Boots",
	inventory_image = "qt_armor_inv_boots_netherite.png",
	groups = {armor_feet=18, armor_heal=10, armor_use=80},
	wear = 0,
})
--poison
minetest.register_tool("qt_armor:helmet_poison", {
	description = "Poison Helmet",
	inventory_image = "qt_armor_inv_helmet_poison.png",
	groups = {armor_head=19, armor_heal=10, armor_use=100},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_poison", {
	description = "Poison Chestplate",
	inventory_image = "qt_armor_inv_chestplate_poison.png",
	groups = {armor_torso=24, armor_heal=10, armor_use=100},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_poison", {
	description = "Poison Leggings",
	inventory_image = "qt_armor_inv_leggings_poison.png",
	groups = {armor_legs=24, armor_heal=10, armor_use=100},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_poison", {
	description = "Poison Boots",
	inventory_image = "qt_armor_inv_boots_poison.png",
	groups = {armor_feet=19, armor_heal=10, armor_use=100},
	wear = 0,
})
--murite
minetest.register_tool("qt_armor:helmet_murite", {
	description = "murite Helmet",
	inventory_image = "qt_armor_inv_helmet_murite.png",
	groups = {armor_head=20, armor_heal=10, armor_use=120},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_murite", {
	description = "murite Chestplate",
	inventory_image = "qt_armor_inv_chestplate_murite.png",
	groups = {armor_torso=25, armor_heal=10, armor_use=120},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_murite", {
	description = "murite Leggings",
	inventory_image = "qt_armor_inv_leggings_murite.png",
	groups = {armor_legs=25, armor_heal=10, armor_use=120},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_murite", {
	description = "murite Boots",
	inventory_image = "qt_armor_inv_boots_murite.png",
	groups = {armor_feet=20, armor_heal=10, armor_use=120},
	wear = 0,
})




--crafting
minetest.register_craft({
	output = 'qt_armor:helmet_elemental',
	recipe = {
		{'qt:farmite_block', 'qt:farmite_block', 'qt:olmite_block'},
		{'qt:farmite_block', '', 'qt:olmite_block'},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = 'qt_armor:chestplate_elemental',
	recipe = {
		{'qt:olmite_block', '', 'qt:olmite_block'},
		{'qt:farmite_block', 'qt:olmite_block', 'qt:farmite_block'},
		{"qt:farmite_block", "qt:farmite_block", "qt:farmite_block"},
	}
})

minetest.register_craft({
	output = 'qt_armor:leggings_elemental',
	recipe = {
		{'qt:farmite_block', 'qt:olmite_block', 'qt:olmite_block'},
		{'qt:farmite_block', '', 'qt:olmite_block'},
		{"qt:farmite_block", "", "qt:olmite_block"},
	}
})

minetest.register_craft({
	output = 'qt_armor:boots_elemental',
	recipe = {
		{'qt:farmite_block', '', 'qt:olmite_block'},
		{'qt:farmite_block', '', 'qt:olmite_block'},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = 'qt_armor:helmet_awesome',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt_armor:helmet_elemental', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:chestplate_awesome',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt_armor:chestplate_elemental', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:leggings_awesome',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt_armor:leggings_elemental', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:boots_awesome',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt_armor:boots_elemental', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:helmet_netherite',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt_armor:helmet_awesome', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:chestplate_netherite',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt_armor:chestplate_awesome', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:leggings_netherite',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt_armor:leggings_awesome', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:boots_netherite',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt_armor:boots_awesome', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

--poison

minetest.register_craft({
	output = 'qt_armor:helmet_poison',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt_armor:helmet_netherite', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:chestplate_poison',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt_armor:chestplate_netherite', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:leggings_poison',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt_armor:leggings_netherite', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:boots_poison',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt_armor:boots_netherite', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

--murite
minetest.register_craft({
	output = 'qt_armor:helmet_murite',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt_armor:helmet_poison', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:chestplate_murite',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt_armor:chestplate_poison', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:leggings_murite',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt_armor:leggings_poison', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	output = 'qt_armor:boots_murite',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt_armor:boots_poison', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})




--specalty
minetest.register_tool("qt_armor:shield_shell", {
	description = "Mutant Turtle Shell Shield",
	inventory_image = "qt_armor_inv_shield_shell.png",
	groups = {armor_shield=17, armor_heal=10, armor_use=500},
	wear = 0,
})

minetest.register_craft({
	output = 'qt_armor:shield_shell',
	recipe = {
		{'qt:turtle_shell', 'qt:turtle_shell', 'qt:turtle_shell'},
		{'qt:turtle_shell', 'qt:turtle_shell', 'qt:turtle_shell'},
		{'', 'qt:turtle_shell', ''},
	}
})

--stuped thing to copy from
--[[
minetest.register_tool("qt_armor:helmet_", {
	description = " Helmet",
	inventory_image = "qt_armor_inv_helmet_.png",
	groups = {armor_head=15, armor_heal=12, armor_use=50},
	wear = 0,
})
minetest.register_tool("qt_armor:chestplate_", {
	description = " Chestplate",
	inventory_image = "qt_armor_inv_chestplate_.png",
	groups = {armor_torso=20, armor_heal=12, armor_use=50},
	wear = 0,
})
minetest.register_tool("qt_armor:leggings_", {
	description = " Leggings",
	inventory_image = "qt_armor_inv_leggings_.png",
	groups = {armor_legs=20, armor_heal=12, armor_use=50},
	wear = 0,
})
minetest.register_tool("qt_armor:boots_", {
	description = " Boots",
	inventory_image = "qt_armor_inv_boots_.png",
	groups = {armor_feet=15, armor_heal=12, armor_use=50},
	wear = 0,
})
--]]
