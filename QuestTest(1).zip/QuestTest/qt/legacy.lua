--legacy

-- minetest.register_alias("name", "convert_to")
-- minetest.register_alias("", "")

--qt_chests
minetest.register_alias("qt_chests:chest_bonus", "qt:chest_bonus")
minetest.register_alias("qt_chests:chest_miner", "qt:chest_miner")
minetest.register_alias("qt_chests:chest_viliger1", "qt:chest_viliger1")
minetest.register_alias("qt_chests:chest_royal", "qt:chest_royal")

--qt_dimensions
minetest.register_alias("qt_dimentions:dimentional_seperator_203948", "qt:dimentional_seperator_203948")
minetest.register_alias("qt_dimentions:nether_stone", "qt:nether_stone")
minetest.register_alias("qt_dimentions:nether_sand", "qt:nether_sand")
minetest.register_alias("qt_dimentions:fireflower_seeds", "qt:fireflower_seeds")
minetest.register_alias("qt_dimentions:fireflower", "qt:fireflower")
minetest.register_alias("qt_dimentions:fireflower_plant_1", "qt:fireflower_plant_1")
minetest.register_alias("qt_dimentions:fireflower_plant_2", "qt:fireflower_plant_2")
minetest.register_alias("qt_dimentions:fireflower_plant_3", "qt:fireflower_plant_3")
minetest.register_alias("qt_dimentions:nether_glass", "qt:nether_glass")
minetest.register_alias("qt_dimentions:nether_warp", "qt:nether_warp")

--qt_dimensions
minetest.register_alias("qt_dungeons:blueprint", "qt:blueprint")
minetest.register_alias("qt_dungeons:pumpkin_block", "qt:pumpkin_block")
minetest.register_alias("qt_dungeons:jackolantern", "qt:jackolantern")
minetest.register_alias("qt_dungeons:zombie_l1", "qt:zombie_l1")
minetest.register_alias("qt_dungeons:zombie_l2", "qt:zombie_l2")
minetest.register_alias("qt_dungeons:skeleton_l1", "qt:skeleton_l1")
minetest.register_alias("qt_dungeons:skeleton_l2", "qt:skeleton_l2")
minetest.register_alias("qt_dungeons:tower_l1", "qt:tower_l1")
minetest.register_alias("qt_dungeons:pumpkin", "qt:pumpkin_zombie")
minetest.register_alias("qt_dungeons:nether_basic", "qt:nether_basic")
minetest.register_alias("qt_dungeons:nether_castle", "qt:nether_castle")

--qt_effects is being ignored, because all items it contains are experamental and will be deleated

--qt_glowstone
minetest.register_alias("qt_glowstone:glowstone", "qt:glowstone")
minetest.register_alias("qt_glowstone:glow_stick", "qt:glow_stick")
minetest.register_alias("qt_glowstone:glow_dust", "qt:glow_dust")

--qt_gold
minetest.register_alias("qt_gold:alloy_gold", "qt:alloy_gold")
minetest.register_alias("qt_gold:gold_stick", "qt:gold_stick")
minetest.register_alias("qt_gold:gold_plate", "qt:gold_plate")
minetest.register_alias("qt_gold:gold_coal", "qt:gold_coal")
minetest.register_alias("qt_gold:firegold", "qt:firegold")
minetest.register_alias("qt_gold:gold_alloy_block", "qt:gold_alloy_block")
minetest.register_alias("qt_gold:gold_pick", "qt:gold_pick")
minetest.register_alias("qt_gold:gold_shovel", "qt:gold_shovel")
minetest.register_alias("qt_gold:gold_axe", "qt:gold_axe")
minetest.register_alias("qt_gold:gold_sword", "qt:gold_sword")
minetest.register_alias("qt_gold:gold_septer", "qt:gold_septer")
minetest.register_alias("qt_gold:gold_apple", "qt:gold_apple")
minetest.register_alias("qt_gold:firegold_sword", "qt:firegold_sword")

--qt_machienes
minetest.register_alias("qt_machienes:hopper", "qt:hopper")
minetest.register_alias("qt_machienes:hopper_side", "qt:hopper_side")

--qt_magic
minetest.register_alias("qt_magic:magic_dust", "qt:magic_dust")
minetest.register_alias("qt_magic:magic_apple", "qt:magic_apple")
minetest.register_alias("qt_magic:magic_wand", "qt:magic_wand")

--qt_mobs

--aliens
minetest.register_alias("qt_mobs:alien_hide", "qt:alien_hide")
minetest.register_alias("qt_mobs:spawn_alien_peaceful", "qt:spawn_alien_peaceful")
minetest.register_alias("qt_mobs:spawner_alien_peaceful", "qt:spawner_alien_peaceful")
minetest.register_alias("qt_mobs:spawn_alien_shooter", "qt:spawn_alien_shooter")
minetest.register_alias("qt_mobs:spawner_alien_shooter", "qt:spawner_alien_shooter")
--experamental
minetest.register_alias("qt_mobs:spawn_pig", "qt:spawn_pig")
minetest.register_alias("qt_mobs:spawn_snowman", "qt:spawn_snowman")
minetest.register_alias("qt_mobs:spawn_droid_gost_x1", "qt:spawn_droid_gost_x1")
minetest.register_alias("qt_mobs:spawn_droid_gost_x2", "qt:spawn_droid_gost_x2")
--nether
minetest.register_alias("qt_mobs:spawn_nether_zombie", "qt:spawn_nether_zombie")
minetest.register_alias("qt_mobs:spawner_nether_zombie", "qt:spawner_nether_zombie")
minetest.register_alias("qt_mobs:spawn_nether_zombie_armored", "qt:spawn_nether_zombie_armored")
minetest.register_alias("qt_mobs:spawner_nether_zombie_armored", "qt:spawner_nether_zombie_armored")
minetest.register_alias("qt_mobs:spawn_demon", "qt:spawn_demon")
minetest.register_alias("qt_mobs:spawner_demon", "qt:spawner_demon")
minetest.register_alias("qt_mobs:spawnnode_demon", "qt:spawnnode_demon")
minetest.register_alias("qt_mobs:spawn_firestorm", "qt:spawn_firestorm")
minetest.register_alias("qt_mobs:spawner_firestorm", "qt:spawner_firestorm")
minetest.register_alias("qt_mobs:spawn_boss_nether_golem", "qt:spawn_boss_nether_golem")
minetest.register_alias("qt_mobs:spawner_boss_nether_golem", "qt:spawner_boss_nether_golem")
minetest.register_alias("qt_mobs:spawn_boss_firey_knight", "qt:spawn_boss_firey_knight")
minetest.register_alias("qt_mobs:spawner_boss_firey_knight", "qt:spawner_boss_firey_knight")
--overworld items
minetest.register_alias("qt_mobs:rotten_flesh", "qt:rotten_flesh")
minetest.register_alias("qt_mobs:meat_raw", "qt:meat_raw")
minetest.register_alias("qt_mobs:meat", "qt:meat")
minetest.register_alias("qt_mobs:bone", "qt:bone")
minetest.register_alias("qt_mobs:armor_frag_diamond", "qt:armor_frag_diamond")
minetest.register_alias("qt_mobs:armor_frag_mese", "qt:armor_frag_mese")
minetest.register_alias("qt_mobs:armor_frag_gold", "qt:armor_frag_gold")
minetest.register_alias("qt_mobs:armor_frag_steel", "qt:armor_frag_steel")
minetest.register_alias("qt_mobs:soul", "qt:soul")
minetest.register_alias("qt_mobs:ent_eyeball", "qt:ent_eyeball")
minetest.register_alias("qt_mobs:pumpkin", "qt:pumpkin_piece")
minetest.register_alias("qt_mobs:skull", "qt:skull")
--overworld
minetest.register_alias("qt_mobs:spawn_zombie", "qt:spawn_zombie")
minetest.register_alias("qt_mobs:spawner_zombie", "qt:spawner_zombie")
minetest.register_alias("qt_mobs:spawn_zombie_armored", "qt:spawn_zombie_armored")
minetest.register_alias("qt_mobs:spawner_zombie_armored", "qt:spawner_zombie_armored")
minetest.register_alias("qt_mobs:spawn_zombie_elite", "qt:spawn_zombie_elite")
minetest.register_alias("qt_mobs:spawner_zombie_elite", "qt:spawner_zombie_elite")
minetest.register_alias("qt_mobs:spawn_skeleton", "qt:spawn_skeleton")
minetest.register_alias("qt_mobs:spawner_skeleton", "qt:spawner_skeleton")
minetest.register_alias("qt_mobs:spawn_skeleton_advanced", "qt:spawn_skeleton_advanced")
minetest.register_alias("qt_mobs:spawner_skeleton_advanced", "qt:spawner_skeleton_advanced")
minetest.register_alias("qt_mobs:spawn_skeleton_carbonized", "qt:spawn_skeleton_carbonized")
minetest.register_alias("qt_mobs:spawner_skeleton_carbonized", "qt:spawner_skeleton_carbonized")
minetest.register_alias("qt_mobs:spawn_criminal", "qt:spawn_criminal")
minetest.register_alias("qt_mobs:spawner_criminal", "qt:spawner_criminal")
minetest.register_alias("qt_mobs:spawn_villager", "qt:spawn_villager")
minetest.register_alias("qt_mobs:spawner_villager", "qt:spawner_villager")
minetest.register_alias("qt_mobs:spawn_sheep", "qt:spawn_sheep")
minetest.register_alias("qt_mobs:spawner_sheep", "qt:spawner_sheep")
minetest.register_alias("qt_mobs:spawn_sheep_magic", "qt:spawn_sheep_magic")
minetest.register_alias("qt_mobs:spawner_sheep_magic", "qt:spawner_sheep_magic")
minetest.register_alias("qt_mobs:spawn_boss_living_sand", "qt:spawn_boss_living_sand")
minetest.register_alias("qt_mobs:spawner_boss_living_sand", "qt:spawner_boss_living_sand")
minetest.register_alias("qt_mobs:spawn_boss_avenging_ent", "qt:spawn_boss_avenging_ent")
minetest.register_alias("qt_mobs:spawner_boss_avenging_ent", "qt:spawner_boss_avenging_ent")
minetest.register_alias("qt_mobs:spawn_boss_zombie_pumpkin", "qt:spawn_boss_zombie_pumpkin")
minetest.register_alias("qt_mobs:spawner_boss_zombie_pumpkin", "qt:spawner_boss_zombie_pumpkin")
minetest.register_alias("qt_mobs:spawnnode_boss_zombie_pumpkin", "qt:spawnnode_boss_zombie_pumpkin")
minetest.register_alias("qt_mobs:spawn_boss_grim_reaper", "qt:spawn_boss_grim_reaper")
minetest.register_alias("qt_mobs:spawner_boss_grim_reaper", "qt:spawner_boss_grim_reaper")

--qt_random
minetest.register_alias("qt_random:random_block", "qt:random_block")
minetest.register_alias("qt_random:present", "qt:present")

--qt_sky
minetest.register_alias("qt_sky:sky_crystal_blue", "qt:sky_crystal_blue")
minetest.register_alias("qt_sky:sky_crystal_node_blue", "qt:sky_crystal_node_blue")
minetest.register_alias("qt_sky:sky_crystal_dark", "qt:sky_crystal_dark")
minetest.register_alias("qt_sky:sky_crystal_node_dark", "qt:sky_crystal_node_dark")
minetest.register_alias("qt_sky:sky_crystal_gold", "qt:sky_crystal_gold")
minetest.register_alias("qt_sky:sky_crystal_node_gold", "qt:sky_crystal_node_gold")
minetest.register_alias("qt_sky:sky_crystal_red", "qt:sky_crystal_red")
minetest.register_alias("qt_sky:sky_crystal_node_red", "qt:sky_crystal_node_red")
minetest.register_alias("qt_sky:sky_crystal_white", "qt:sky_crystal_white")
minetest.register_alias("qt_sky:sky_crystal_node_white", "qt:sky_crystal_node_white")
minetest.register_alias("qt_sky:sky_crystal_node_green", "qt:sky_crystal_node_green")
minetest.register_alias("qt_sky:sky_crystal_green", "qt:sky_crystal_green")

minetest.register_alias("qt_sky:net", "qt:net")
minetest.register_alias("qt_sky:sword_sky_crystal_gold", "qt:sword_sky_crystal_gold")
minetest.register_alias("qt_sky:sky_crystal_hammer", "qt:sky_crystal_hammer")

--qt_tools
minetest.register_alias("qt_tools:scythe", "qt:scythe")
minetest.register_alias("qt_tools:ent_sword", "qt:ent_sword")
minetest.register_alias("qt_tools:elemental_pick", "qt:elemental_pick")
minetest.register_alias("qt_tools:elemental_shovel", "qt:elemental_shovel")
minetest.register_alias("qt_tools:elemental_axe", "qt:elemental_axe")
minetest.register_alias("qt_tools:elemental_sword", "qt:elemental_sword")
minetest.register_alias("qt_tools:awesome_pick", "qt:awesome_pick")
minetest.register_alias("qt_tools:awesome_shovel", "qt:awesome_shovel")
minetest.register_alias("qt_tools:awesome_axe", "qt:awesome_axe")
minetest.register_alias("qt_tools:awesome_sword", "qt:awesome_sword")
minetest.register_alias("qt_tools:netherite_gem", "qt:netherite_gem")
minetest.register_alias("qt_tools:netherite_pick", "qt:netherite_pick")
minetest.register_alias("qt_tools:netherite_shovel", "qt:netherite_shovel")
minetest.register_alias("qt_tools:netherite_axe", "qt:netherite_axe")
minetest.register_alias("qt_tools:netherite_sword", "qt:netherite_sword")

--minetest.register_alias("", "qt:")
--minetest.register_alias("qt_tools:", "qt:")


--[[
scythe
ent_sword
elemental_pick
elemental_shovel
elemental_axe
elemental_sword
awesome_pick
awesome_shovel
awesome_axe
awesome_sword
netherite_gem
netherite_pick
netherite_shovel
netherite_axe
netherite_sword
net
sky_crystal_blue
sky_crystal_node_blue
sky_crystal_dark
sky_crystal_node_dark
sky_crystal_gold
sky_crystal_node_gold
sky_crystal_green
sky_crystal_node_green
sky_crystal_red
sky_crystal_node_red
sky_crystal_white
sky_crystal_node_white
sword_sky_crystal_gold
sky_crystal_hammer
random_block
present
spawn_zombie
spawner_zombie
spawn_zombie_armored
spawner_zombie_armored
spawn_zombie_elite
spawner_zombie_elite
spawn_skeleton
spawner_skeleton
spawn_skeleton_advanced
spawner_skeleton_advanced
spawn_skeleton_carbonized
spawner_skeleton_carbonized
spawn_criminal
spawner_criminal
spawn_villager
spawner_villager
spawn_sheep
spawner_sheep
spawn_sheep_magic
spawner_sheep_magic
spawn_boss_living_sand
spawner_boss_living_sand
spawn_boss_avenging_ent
spawner_boss_avenging_ent
spawn_boss_zombie_pumpkin
spawner_boss_zombie_pumpkin
spawnnode_boss_zombie_pumpkin
spawn_boss_grim_reaper
spawner_boss_grim_reaper
qt_mobs:rotten_flesh
qt_mobs:meat_raw
qt_mobs:meat
qt_mobs:bone
qt_mobs:armor_frag_diamond
qt_mobs:armor_frag_mese
qt_mobs:armor_frag_gold
qt_mobs:armor_frag_steel
qt_mobs:soul
qt_mobs:ent_eyeball
qt_mobs:pumpkin (qt:pumpkin_piece)
qt_mobs:skull
qt_mobs:spawn_nether_zombie
qt_mobs:spawner_nether_zombie
qt_mobs:spawn_nether_zombie_armored
qt_mobs:spawner_nether_zombie_armored
qt_mobs:spawn_demon
qt_mobs:spawner_demon
qt_mobs:spawnnode_demon
qt_mobs:spawn_firestorm
qt_mobs:spawner_firestorm
qt_mobs:spawn_boss_nether_golem
qt_mobs:spawner_boss_nether_golem
qt_mobs:spawn_boss_firey_knight
qt_mobs:spawner_boss_firey_knight
qt_mobs:spawn_pig
qt_mobs:spawn_snowman
qt_mobs:spawn_droid_gost_x1
qt_mobs:spawn_droid_gost_x2
qt_mobs:alien_hide
qt_mobs:spawn_alien_peaceful
qt_mobs:spawner_alien_peaceful
qt_mobs:spawn_alien_shooter
qt_mobs:spawner_alien_shooter
qt_magic:magic_dust
qt_magic:magic_apple
qt_magic:magic_wand
qt_machienes:hopper
qt_machienes:hopper_side
qt_gold:alloy_gold
qt_gold:gold_stick
qt_gold:gold_plate
qt_gold:gold_coal
qt_gold:firegold
qt_gold:gold_alloy_block
qt_gold:gold_pick
qt_gold:gold_shovel
qt_gold:gold_axe
qt_gold:gold_sword
qt_gold:gold_septer
qt_gold:gold_apple
qt_gold:firegold_sword
qt_glowstone:glowstone
qt_glowstone:glow_stick
qt_glowstone:glow_dust
qt_chests:chest_bonus
qt_chests:chest_miner
qt_chests:chest_viliger1
qt_chests:chest_royal
qt_dimentions:dimentional_seperator_203948
qt_dimentions:nether_stone
qt_dimentions:nether_sand
qt_dimentions:fireflower_seeds
qt_dimentions:fireflower
qt_dimentions:fireflower_plant_1
qt_dimentions:fireflower_plant_2
qt_dimentions:fireflower_plant_3
qt_dimentions:nether_glass
qt_dimentions:nether_warp
qt_dungeons:blueprint
qt_dungeons:pumpkin_block
qt_dungeons:jackolantern
qt_dungeons:zombie_l1
qt_dungeons:zombie_l2
qt_dungeons:skeleton_l1
qt_dungeons:skeleton_l2
qt_dungeons:tower_l1
qt_dungeons:pumpkin (qt_dungeons:pumpkin_zombie)
qt_dungeons:nether_basic
qt_dungeons:nether_castle
--]]
