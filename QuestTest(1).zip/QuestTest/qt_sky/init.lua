--qt

minetest.register_tool(":qt:net", {
	description = "Net",
	inventory_image = "net.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			sky_ore = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_craft({
	output = 'qt:net',
	recipe = {
		{'', 'group:stick', ''},
		{'group:stick', 'farming:string', 'group:stick'},
		{'group:stick', 'group:stick', ''},
	}
})

minetest.register_craftitem(":qt:sky_crystal_blue", {
	description = "Blue Sky Crystal",
	inventory_image = "sky_crystal_blue.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_blue", {
	description = "Blue Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_blue.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_blue",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_blue",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_craftitem(":qt:sky_crystal_dark", {
	description = "Dark Sky Crystal",
	inventory_image = "sky_crystal_dark.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_dark", {
	description = "Dark Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_dark.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_dark",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_dark",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_craftitem(":qt:sky_crystal_gold", {
	description = "Gold Sky Crystal",
	inventory_image = "sky_crystal_gold.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_gold", {
	description = "Gold Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_gold.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_gold",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_gold",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_craftitem(":qt:sky_crystal_green", {
	description = "Green Sky Crystal",
	inventory_image = "sky_crystal_green.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_green", {
	description = "Green Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_green.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_green",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_green",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_craftitem(":qt:sky_crystal_red", {
	description = "Red Sky Crystal",
	inventory_image = "sky_crystal_red.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_red", {
	description = "Red Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_red.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_red",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_red",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_craftitem(":qt:sky_crystal_white", {
	description = "White Sky Crystal",
	inventory_image = "sky_crystal_white.png",
	groups =  {sky_crystal = 1},
})

minetest.register_node(":qt:sky_crystal_node_white", {
	description = "White Gem Ore",
	drawtype = "plantlike",
	paramtype = "light",
	tiles = {"sky_crystal_white.png"},
	is_ground_content = true,
	groups = {sky_ore = 1},
	drop = "qt:sky_crystal_white",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:sky_crystal_node_white",
	wherein        = "air",
	clust_scarcity = 50*50*50,
	clust_num_ores = 3,
	clust_size     = 4,
	height_min     = 10,
	height_max     = 10000,
	flags          = "absheight",
})

minetest.register_tool(":qt:sword_sky_crystal_gold", {
	description = "Golden Sky Crystal Sword",
	inventory_image = "sky_crystal_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.3,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.80, [2]=0.80, [3]=0.20}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=10},
	}
})

minetest.register_craft({
	output = 'qt:sword_sky_crystal_gold',
	recipe = {
		{'qt:sky_crystal_gold'},
		{'qt:sky_crystal_gold'},
		{'group:stick'},
	}
})

local function remove_stone (pos)
local newpos = { x = pos.x-1, y = pos.y-1, z = pos.z-1}
	for xa = 0, 2, 1 do
	for ya = 0, 2, 1 do
	for za = 0, 2, 1 do
		local inpos = {x = newpos.x + xa, y = newpos.y + ya, z = newpos.z + za}
		local node = minetest.env:get_node(inpos)
		if node.name == "default:stone" then
			minetest.remove_node(inpos)
		end
	end
	end
	end
end

minetest.register_tool(":qt:sky_crystal_hammer", {
	description = "Sky Crystal Hammer",
	inventory_image = "sky_crystal_hammer.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			remove_stone (pointed_thing.under)
		end
	end,
})

minetest.register_craft({
	output = 'qt:sky_crystal_hammer',
	recipe = {
		{'group:sky_crystal', 'group:sky_crystal', 'group:sky_crystal'},
		{'group:sky_crystal', 'group:stick', 'group:sky_crystal'},
		{'', 'group:stick', ''},
	}
})
