--qt_random

local actions  =  60

minetest.register_node(":qt:random_block", {
	description = "Random Block!!!!!!!!!!!",
	tiles = {"random.png"},
	is_ground_content = false,
	groups = {oddly_breakable_by_hand=2},
	on_dig = function(pos, node, digger)
		local rn = math.random(1, actions)
		--local rn = math.random(53, actions)
		if rn == 1 then
			minetest.add_item(pos,'default:stick 11')
			minetest.remove_node (pos)
		end
		if rn == 2 then
			minetest.add_item(pos, 'default:stick 9')
			minetest.remove_node (pos)
		end
		if rn == 3 then
			minetest.add_item(pos,'default:stick 3')
			minetest.remove_node (pos)
		end
		if rn == 4 then
			minetest.add_item(pos,'default:diamond 5')
			minetest.remove_node (pos)
		end
		if rn == 5 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:diamondblock"})
		end
		if rn == 6 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:block_gem_blue"})
		end
		if rn == 7 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:block_gem_red"})
		end
		if rn == 8 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:block_gem_green"})
		end
		if rn == 9 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:block_gem_sky_blue"})
		end
		if rn == 10 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:mese"})
		end
		if rn == 11 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:goldblock"})
		end
		if rn == 12 then
			minetest.add_item(pos,'default:apple 10')
			minetest.remove_node (pos)
		end
		if rn == 13 then
			minetest.remove_node (pos)
			minetest.add_item(pos,'farming:bread 7')
		end
		if rn == 14 then
			minetest.remove_node (pos)
			minetest.add_item(pos,'qt_gold:gold_apple 7')
		end
		if rn == 15 then
			minetest.remove_node (pos)
			minetest.add_item(pos,'qt:pumpkin 7')
		end
		if rn == 16 then
			minetest.remove_node (pos)
			minetest.add_item(pos,'qt:meat 7')
		end
		if rn == 17 then
			minetest.remove_node (pos)
			minetest.add_item(pos,'qt_magic:magic_apple 3')
		end
		if rn == 18 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:water_source"})
		end
		if rn == 19 then
			minetest.remove_node (pos)
			qt.explode(pos, 3)
		end
		if rn == 20 then
			minetest.remove_node (pos)
			qt.explode(pos, 7)
		end
		if rn == 21 then
			minetest.remove_node (pos)
			minetest.add_entity(pos, "qt:boss_living_sand")
		end
		if rn == 22 then
			minetest.remove_node (pos)
			minetest.add_entity(pos, "qt:boss_avenging_ent")
		end
		if rn == 23 then
			minetest.remove_node (pos)
			minetest.add_entity({x = pos.x, y = pos.y + 1, z = pos.z}, "qt:boss_zombie_pumpkin")
		end
		if rn == 24 then
			minetest.remove_node (pos)
			minetest.add_entity(pos, "qt:boss_grim_reaper")
		end
		if rn == 25 then
			minetest.remove_node (pos)
			minetest.add_entity({x = pos.x, y = pos.y + 1, z = pos.z}, "qt:villager")
		end
		if rn == 26 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:dirt"})
		end
		if rn == 27 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:sand"})
		end
		if rn == 28 then
			minetest.add_item(pos,'qt:gem_red 5')
			minetest.remove_node (pos)
		end
		if rn == 29 then
			minetest.add_item(pos,'qt:gem_green 5')
			minetest.remove_node (pos)
		end
		if rn == 30 then
			minetest.add_item(pos,'qt:gem_blue 5')
			minetest.remove_node (pos)
		end
		if rn == 31 then
			minetest.add_item(pos,'qt:gem_sky_blue 5')
			minetest.remove_node (pos)
		end
		if rn == 32 then
			minetest.add_item(pos,'default:mese_crystal 7')
			minetest.remove_node (pos)
		end
		if rn == 33 then
			minetest.add_item(pos,'dye:white')
			minetest.add_item(pos,'dye:grey')
			minetest.add_item(pos,'dye:dark_grey')
			minetest.add_item(pos,'dye:black')
			minetest.add_item(pos,'dye:violet')
			minetest.add_item(pos,'dye:blue')
			minetest.add_item(pos,'dye:cyan')
			minetest.add_item(pos,'dye:dark_green')
			minetest.add_item(pos,'dye:green')
			minetest.add_item(pos,'dye:yellow')
			minetest.add_item(pos,'dye:brown')
			minetest.add_item(pos,'dye:orange')
			minetest.add_item(pos,'dye:red')
			minetest.add_item(pos,'dye:magenta')
			minetest.add_item(pos,'dye:pink')
			minetest.remove_node (pos)
		end
		if rn == 34 then
			minetest.add_item(pos,'wool:white')
			minetest.add_item(pos,'wool:grey')
			minetest.add_item(pos,'wool:dark_grey')
			minetest.add_item(pos,'wool:black')
			minetest.add_item(pos,'wool:violet')
			minetest.add_item(pos,'wool:blue')
			minetest.add_item(pos,'wool:cyan')
			minetest.add_item(pos,'wool:dark_green')
			minetest.add_item(pos,'wool:green')
			minetest.add_item(pos,'wool:yellow')
			minetest.add_item(pos,'wool:brown')
			minetest.add_item(pos,'wool:orange')
			minetest.add_item(pos,'wool:red')
			minetest.add_item(pos,'wool:magenta')
			minetest.add_item(pos,'wool:pink')
			minetest.remove_node (pos)
		end
		if rn == 35 then
			minetest.remove_node (pos)
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z}, {name = "default:stone"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z}, {name = "default:stone"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z}, {name = "default:stone"})
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z+1}, {name = "default:stone"})
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z-1}, {name = "default:stone"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z+1}, {name = "default:stone"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z-1}, {name = "default:stone"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z+1}, {name = "default:stone"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z-1}, {name = "default:stone"})
			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z+1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z-1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z+1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z-1}, {name = "qt_random:random_block"})
		end
		if rn == 36 then
			minetest.add_item(pos,'default:clay_lump 11')
			minetest.remove_node (pos)
		end
		if rn == 37 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:clay"})
		end
		if rn == 38 then
			minetest.add_item(pos,'default:book 33')
			minetest.remove_node (pos)
		end
		if rn == 39 then
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			minetest.add_item(pos,'default:mese_crystal_fragment 99')
			--inventory bomber, if they pick them up!
			minetest.remove_node (pos)
		end
		if rn == 40 then
			minetest.add_item(pos,'default:obsidian_shard 33')
			minetest.add_item(pos,'default:obsidian 5')
			minetest.remove_node (pos)
		end
		if rn == 41 then
			minetest.add_item(pos,'bucket:bucket_empty')
			minetest.add_item(pos,'bucket:bucket_empty')
			minetest.add_item(pos,'bucket:bucket_water')
			minetest.add_item(pos,'bucket:bucket_water')
			minetest.add_item(pos,'bucket:bucket_lava')
			minetest.add_item(pos,'bucket:bucket_lava')
			minetest.remove_node (pos)
		end
		--if rn == 43 then
			--minetest.chat_send_player(digger, "You are so Lucky!") -- LOL
			--minetest.remove_node (pos)
		--end
		if rn == 42 then
			minetest.remove_node (pos)
			--pyramid
			--core block
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z}, {name = "default:sandstonebrick"})

			--base
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y-1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y-1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y-1, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y-1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y-1, z = pos.z-2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y-1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y-1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y-1, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y-1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y-1, z = pos.z-2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z+2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x, y = pos.y-1, z = pos.z-2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y-1, z = pos.z-2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y-1, z = pos.z-2}, {name = "default:sandstonebrick"})

			--layer1
			minetest.set_node({x = pos.x+2, y = pos.y, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+2, y = pos.y, z = pos.z-2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x-2, y = pos.y, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-2, y = pos.y, z = pos.z-2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x, y = pos.y, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z+2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x, y = pos.y, z = pos.z-2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z-2}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z-2}, {name = "default:sandstonebrick"})

			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z+1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x+1, y = pos.y, z = pos.z-1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z+1}, {name = "qt_random:random_block"})
			minetest.set_node({x = pos.x-1, y = pos.y, z = pos.z-1}, {name = "qt_random:random_block"})

			--layer2
			minetest.set_node({x = pos.x, y = pos.y+1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x, y = pos.y+1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y+1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y+1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x+1, y = pos.y+1, z = pos.z-1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y+1, z = pos.z}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y+1, z = pos.z+1}, {name = "default:sandstonebrick"})
			minetest.set_node({x = pos.x-1, y = pos.y+1, z = pos.z-1}, {name = "default:sandstonebrick"})

			--layer3
			minetest.set_node({x = pos.x, y = pos.y+2, z = pos.z}, {name = "default:sandstonebrick"})
		end

		if rn == 43 then
			minetest.remove_node (pos)
			for a = 0, 10 do
				minetest.set_node({x = pos.x, y = pos.y+a, z = pos.z}, {name = "qt:farmite_block"})
			end
		end

		if rn == 44 then
			minetest.remove_node (pos)
			for a = 0, 10 do
				minetest.set_node({x = pos.x, y = pos.y+a, z = pos.z}, {name = "qt:olmite_block"})
			end
		end

		if rn == 45 then
			minetest.remove_node (pos)
			for a = 0, 10 do
				minetest.set_node({x = pos.x, y = pos.y+a, z = pos.z}, {name = "qt:gunpowder_block"})
			end
		end

		if rn == 46 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "default:lava_source"})
		end
		if rn == 47 then
			minetest.add_item(pos,'qt:arrow 99')
			minetest.remove_node (pos)
		end
		if rn == 48 then
			minetest.add_item(pos,'qt:bow_med')
			minetest.remove_node (pos)
		end
		if rn == 49 then
			minetest.add_item(pos,'qt:bow_high')
			minetest.remove_node (pos)
		end
		if rn == 50 then
			minetest.add_item(pos,'qt:bow_obsidian')
			minetest.remove_node (pos)
		end
		if rn == 50 then
			minetest.add_item(pos,'qt:bow_fire')
			minetest.remove_node (pos)
		end
		if rn == 50 then
			minetest.add_item(pos,'qt:bow_lava')
			minetest.remove_node (pos)
		end
		if rn == 50 then
			minetest.add_item(pos,'qt:bow_water')
			minetest.remove_node (pos)
		end
		if rn == 50 then
			minetest.add_item(pos,'qt:bow_ice')
			minetest.remove_node (pos)
		end
		if rn == 51 then
			minetest.remove_node (pos)
			minetest.add_entity(pos, "qt:gold_tnt_entity")
		end
		if rn == 52 then
			minetest.remove_node (pos)
			local ppos = digger:getpos()
			digger:setpos({x = ppos.x, y = ppos.y+100, z = ppos.z})
		end
		if rn == 53 then
			minetest.remove_node (pos)
			local aplayerpos = digger:getpos()
			minetest.set_node({x = aplayerpos.x, y = aplayerpos.y+2, z = aplayerpos.z}, {name = "default:sand"})
			minetest.set_node({x = aplayerpos.x, y = aplayerpos.y+3, z = aplayerpos.z}, {name = "default:sand"})
			nodeupdate({x = aplayerpos.x, y = aplayerpos.y+2, z = aplayerpos.z})
			minetest.debug("sand action")
		end
		if rn == 54 then
			minetest.remove_node (pos)
			local b_player_pos = digger:getpos()

			--[[
			minetest.debug("playerpos gotten")
			if bplayerpos ~= nil then
				minetest.debug("playerpos not nil")
				if bplayerpos.x ~= nil then
					minetest.debug("playerpos.x not nil")
				else
					minetest.debug("ERROR[QuestTest]: playerpos.x is nil")
				end

				if bplayerpos.y ~= nil then
					minetest.debug("playerpos.y not nil")
				else
					minetest.debug("ERROR[QuestTest]: playerpos.y is nil")
				end

				if bplayerpos.z ~= nil then
					minetest.debug("playerpos.z not nil")
				else
					minetest.debug("ERROR[QuestTest]: playerpos.z is nil")
				end
			else
				minetest.debug("ERROR[QuestTest]: playerpos is nil")
			end
			--]]


			for by = b_player_pos.y+1, b_player_pos.y-50, -1 do
			for bx = b_player_pos.x-1, b_player_pos.x+1 do
			for bz = b_player_pos.z-1, b_player_pos.z+1 do
				minetest.remove_node ({x=bx, y=by, z=bz})
				--minetest.debug("node removed action, z loop run")
			end
				--minetest.debug("x loop run")
			end
				--minetest.debug("y loop run")
			end


			--for vx = 0, -10, -1 do
			minetest.debug("hole action")
		end
		if rn == 55 then
			minetest.remove_node (pos)
			local cplayerpos = digger:getpos()
			minetest.set_node(cplayerpos, {name = "default:lava_source"})
		end
		if rn == 56 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:poison_liquid_source"})
		end
		if rn == 57 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:yellow_slime_source"})
		end
		if rn == 58 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:jade_block"})
		end
		if rn == 59 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:poison_gem_block"})
		end
		if rn == 60 then
			minetest.remove_node (pos)
			minetest.set_node(pos, {name = "qt:netherite_block"})
		end
	end
})




minetest.register_craft({
	output = 'qt:random_block 2',
	recipe = {
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
		{'qt:gem_blue', 'default:steelblock', 'qt:gem_blue'},
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
	}
})

minetest.register_craft({
	output = 'qt:random_block 4',
	recipe = {
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
		{'qt:gem_blue', 'default:goldblock', 'qt:gem_blue'},
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
	}
})

minetest.register_node(":qt:present", {
	description = "Christmas Present",
	tiles = {"present_top.png", "present_top.png", "present_side.png",
		"present_side.png", "present_side.png", "present_side.png"},
	paramtype2 = "facedir",
	groups = {oddly_breakable_by_hand=1},
	legacy_facedir_simple = true,
	is_ground_content = false,
	sounds = default.node_sound_defaults(),
	drop = {
		max_items = 1,
		items = {
			{
				items = {'default:snowblock 1'},
				rarity = 20,
			},
			{
				items = {'default:ice 1'},
				rarity = 20,
			},
			{
				items = {'qt:spawn_snowman 1'},
				rarity = 20,
			},
			{
				items = {'default:snowblock 2'},
				rarity = 20,
			},
			{
				items = {'default:ice 2'},
				rarity = 20,
			},
			{
				items = {'qt:spawn_snowman 2'},
				rarity = 20,
			},
			{
				items = {'default:snowblock 3'},
				rarity = 20,
			},
			{
				items = {'default:ice 3'},
				rarity = 20,
			},
			{
				items = {'qt:spawn_snowman 3'},
				rarity = 20,
			},
			{
				items = {'default:snow 2'},
			}
		}
	},
})

minetest.register_craft({
	output = 'qt:present',
	recipe = {
		{'group:basecolor_red', 'group:basecolor_red', 'group:basecolor_green'},
		{'default:paper', 'default:paper', ''},
		{'default:paper', 'default:paper', ''},
	}
})
