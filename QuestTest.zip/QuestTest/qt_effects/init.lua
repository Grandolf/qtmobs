--qt_effects
--this mod adds status effects

--effect_type_id, description, icon, groups, apply, cancel, hidden, cancel_on_death, repeat_interval

dofile(minetest.get_modpath("qt_effects").."/api.lua")

playereffects.register_effect_type("speed", "Speed 1", nil, {"speed"},
	function(player)
		qt_effects.set_player_physics(player, {
			speed = 1,
			jump = 0,
			gravity = 0,
		})
		--player:set_physics_override(2,1.1,nil)
	end,

	function(effect, player)
		--player:set_physics_override(1,1,nil)
		qt_effects.set_player_physics(player, {
			speed = -1,
			jump = 0,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("speed_2", "Speed 2", nil, {"speed"},
	function(player)
		qt_effects.set_player_physics(player, {
			speed = 2,
			jump = 0,
			gravity = 0,
		})
		--player:set_physics_override(2,1.1,nil)
	end,

	function(effect, player)
		--player:set_physics_override(1,1,nil)
		qt_effects.set_player_physics(player, {
			speed = -2,
			jump = 0,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("slowness", "Slowness 1", nil, {"slowness"},
	function(player)
		--player:set_physics_override(.5,nil,nil)
		qt_effects.set_player_physics(player, {
			speed = -0.5,
			jump = 0,
			gravity = 0,
		})
	end,

	function(effect, player)
		--player:set_physics_override(1,nil,nil)
		qt_effects.set_player_physics(player, {
			speed = 0.5,
			jump = 0,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("slowness_2", "Slowness 2", nil, {"slowness"},
	function(player)
		--player:set_physics_override(.5,nil,nil)
		qt_effects.set_player_physics(player, {
			speed = -0.9,
			jump = 0,
			gravity = 0,
		})
	end,

	function(effect, player)
		--player:set_physics_override(1,nil,nil)
		qt_effects.set_player_physics(player, {
			speed = 0.9,
			jump = 0,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("jump_boost", "Jump Boost 1", nil, {"jump"},
	function(player)
		--player:set_physics_override(nil,2,nil)
		qt_effects.set_player_physics(player, {
			speed = 0,
			jump = 1,
			gravity = 0,
		})
	end,
	function(effect, player)
		--player:set_physics_override(nil,1,nil)
		qt_effects.set_player_physics(player, {
			speed = 0,
			jump = -1,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("jump_boost_2", "Jump Boost 2", nil, {"jump"},
	function(player)
		--player:set_physics_override(nil,2,nil)
		qt_effects.set_player_physics(player, {
			speed = 0,
			jump = 2,
			gravity = 0,
		})
	end,
	function(effect, player)
		--player:set_physics_override(nil,1,nil)
		qt_effects.set_player_physics(player, {
			speed = 0,
			jump = -2,
			gravity = 0,
		})
	end
)

playereffects.register_effect_type("flying", "Flying", nil, {"flying"},
	function(player)
		--player:set_physics_override(nil,2,nil)
		qt_effects.set_player_physics(player, {
			speed = 2,
			jump = 0,
			gravity = -0.98,
		})
	end,
	function(effect, player)
		--player:set_physics_override(nil,1,nil)
		qt_effects.set_player_physics(player, {
			speed = -2,
			jump = 0,
			gravity = 0.98,
		})
	end,
	true
)


--[[
playereffects.register_effect_type("speed_and_jump", "Jump Boost 1", nil, {"jump", "speed"},
	function(player)
		player:set_physics_override(2,2,nil)
	end,
	function(effect, player)
		player:set_physics_override(1,1,nil)
	end
)
--]]

--non physics-overriding effects

playereffects.register_effect_type("regen", "Regeneration", "heart.png", {"regen"},
	function(player)
		player:set_hp(player:get_hp()+1)
	end,
	nil, nil, nil, 0.5
)

playereffects.register_effect_type("regen_2", "Regeneration 2", "heart.png", {"regen"},
	function(player)
		player:set_hp(player:get_hp()+2)
	end,
	nil, nil, nil, 0.5
)

playereffects.register_effect_type("harming", "Harming", "heart.png", {"harming"},
	function(player)
		player:set_hp(player:get_hp()-1)
	end,
	nil, nil, nil, 1
)

playereffects.register_effect_type("harming_2", "Harming 2", "heart.png", {"harming"},
	function(player)
		player:set_hp(player:get_hp()-2)
	end,
	nil, nil, nil, 1
)

playereffects.register_effect_type("poison", "Poison 1", "heart.png", {"poison"},
	function(player)
		local hp = player:get_hp()
		if hp > 1 then
			player:set_hp(hp-1)
		end
	end,
	nil, nil, nil, 1.5
)

playereffects.register_effect_type("poison_2", "Poison 2", "heart.png", {"poison"},
	function(player)
		local hp = player:get_hp()
		if hp > 2 then
			player:set_hp(hp-2)
		elseif hp == 2 then
			player:set_hp(hp-1)
		end
	end,
	nil, nil, nil, 1.5
)
--[[
playereffects.register_effect_type("drowning", "Drowning 1", "heart.png", {"drowning"},
	function(player)
		player:set_breath(player:get_breath()-2)
	end,
	nil, nil, nil, 0.5
)

playereffects.register_effect_type("drowning_2", "Drowning 2", "heart.png", {"drowning"},
	function(player)
		player:set_breath(player:get_breath()-4)
	end,
	nil, nil, nil, 0.5
)
--]]
--experimental tools to test the application of a status effect.
minetest.register_tool("qt_effects:drowning_item", {
	description = "Drowning Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("jump_boost_2", 30, user)
	end
})


--[[
minetest.register_tool("qt_effects:drowning_item", {
	description = "Drowning Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("jump_boost_2", 30, user)
	end
})

minetest.register_tool("qt_effects:speed_item", {
	description = "Speed Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("speed", 15, user)
	end
})

minetest.register_tool(":qt_effects:slowness_item", {
	description = "Slowness Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("slowness", 15, user)
	end
})

minetest.register_tool(":qt_effects:jump_item", {
	description = "Jump Boost Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("jump_boost", 15, user)
	end
})
--]]

--useful chatcommand to cancel all effects

minetest.register_chatcommand("cancelall", {
	params = "",
	description = "Cancels all your effects.",
	privs = {},
	func = function(name, param)
		local effects = playereffects.get_player_effects(name)
		for e=1, #effects do
			playereffects.cancel_effect(effects[e].effect_id)
		end
		minetest.chat_send_player(name, "All effects cancelled.")
	end,
})
