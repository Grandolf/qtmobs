--qt

minetest.register_tool(":qt:scythe", {
	description = "The Grim Reaper's Scythe",
	inventory_image = "scythe.png",
	tool_capabilities = {
		full_punch_interval = 0.2,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.60, [3]=0.30}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=14},
	},
	visual_scale = 2.0
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:scythe',
	recipe = {'qt:scythe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:ent_sword", {
	description = "Ent Sword",
	inventory_image = "ent_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.2,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.60, [3]=0.30}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=11},
	},
	visual_scale = 2.0
})

minetest.register_craft({
	output = 'qt:ent_sword',
	recipe = {
		{'default:steelblock'},
		{'default:steelblock'},
		{'qt_mobs:ent_eyeball'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:ent_sword',
	recipe = {'qt:ent_sword', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:sapphire_big_sword", {
	description = "Sapphire BIGsword",
	inventory_image = "sapphire_big_sword.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.60, [3]=0.30}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=17},
	},
	visual_scale = 2.0
})

minetest.register_craft({
	output = 'qt:sapphire_big_sword',
	recipe = {
		{'', 'qt:gem_blue', 'qt:block_gem_blue'},
		{'qt:gem_blue', 'qt:block_gem_blue', 'qt:gem_blue'},
		{'group:stick', 'qt:gem_blue', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sapphire_big_sword',
	recipe = {'qt:sapphire_big_sword', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:emerald_axe", {
	description = "Emerald Axe",
	inventory_image = "emerald_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.60, [3]=0.30}, uses=100, maxlevel=3},
		},
		damage_groups = {fleshy=16},
	},
	visual_scale = 2.0
})

minetest.register_craft({
	output = 'qt:emerald_axe',
	recipe = {
		{'qt:block_gem_green', 'qt:block_gem_green', 'qt:block_gem_green'},
		{'qt:block_gem_green', 'qt:alloy_gold', 'qt:block_gem_green'},
		{'', 'qt:alloy_gold', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:emerald_axe',
	recipe = {'qt:emerald_axe', 'qt_magic:magic_dust'},
})


minetest.register_tool(":qt:soul_reaping_knife", {
	description = "Soul Reaping Knife",
	inventory_image = "soul_reaping_knife.png",
	tool_capabilities = {
		full_punch_interval = 0.1,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.60, [3]=0.30}, uses=1, maxlevel=3},
		},
		damage_groups = {fleshy=10000},
	},
})

minetest.register_craft({
	output = 'qt:soul_reaping_knife',
	recipe = {
		{'', '', 'soul_reaper_gem'},
		{'', 'soul_reaper_gem', ''},
		{'default:steel_ingot', '', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:soul_reaping_knife',
	recipe = {'qt:soul_reaping_knife', 'qt_magic:magic_dust'},
})


local function dig_area (pos, player)
local newpos = { x = pos.x-1, y = pos.y-1, z = pos.z-1}
	for xa = 0, 2, 1 do
	for ya = 0, 2, 1 do
	for za = 0, 2, 1 do
		local inpos = {x = newpos.x + xa, y = newpos.y + ya, z = newpos.z + za}
		local node = minetest.env:get_node(inpos)
		local node_dat = minetest.registered_nodes[node.name]
		if node_dat.groups.cracky~=nil or node_dat.groups.crumbly~=nil or node_dat.groups.choppy~=nil or node_dat.groups.snappy~=nil then
			minetest.node_dig(inpos, node, player)
		end
	end
	end
	end
end

minetest.register_tool(":qt:wand_jade", {
	description = "Jade Wand",
	inventory_image = "jade_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			dig_area (pointed_thing.under, user)
			itemstack:add_wear(65535/15000)
			return itemstack
		end
	end
})

minetest.register_craft({
	output = 'qt:wand_jade',
	recipe = {
		{'qt:jade_block'},
		{'qt:gold_stick'},
		{'qt:gold_stick'},
	}
})

--[[
minetest.register_node(":qt:ruby_laser_shot_node", {
	tiles = {
		"ruby_laser_shot.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.0625, -0.0625, 10.625, 0.0625, 0.0625}, -- NodeBox1
		}
	}
})

minetest.register_craftitem(":qt:ruby_laser_charge", {
	description = "Ruby Laser Charge",
	inventory_image = "ruby_laser_charge.png",
	})

qt.register_shooter({
	shootername = ":qt:ruby_laser_gun",
	is_shooter_tool = true,
	tool_wear = 5000000,
	shooter_image = "ruby_laser_gun.png",
	shooter_def = "Ruby Laser Gun",
	take_ammo = true,
	ammo_name = "qt:ruby_laser_charge",
	entity_name = ":qt:ruby_laser_gun_entity",
	entity_image = {":qt:ruby_laser_shot_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 25,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:gun_diamond',
	recipe = {
		{'default:diamondblock', 'default:diamondblock', 'default:diamond'},
		{'default:steel_ingot', 'default:diamond', ''},
		{'default:steel_ingot', 'default:wood', ''},
	}
})
--]]


--Elemental Set
minetest.register_tool(":qt:elemental_pick", {
	description = "Elemental Pickaxe",
	inventory_image = "elemental_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.90, [2]=0.90, [3]=0.40}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
})

minetest.register_craft({
	output = 'qt:elemental_pick',
	recipe = {
		{'qt:olmite_block', 'qt:farmite_block', 'qt:olmite_block'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:elemintal_pick',
	recipe = {'qt:elemintal_pick', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:elemental_shovel", {
	description = "Elemental Shovel",
	inventory_image = "elemental_shovel.png",
	wield_image = "elemental_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.00, [2]=0.40, [3]=0.20}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_craft({
	output = 'qt:elemental_shovel',
	recipe = {
		{'qt:olmite_block'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:elemental_shovel',
	recipe = {
		{'qt:farmite_block'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:elemental_shovel',
	recipe = {'qt:elemental_shovel', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:elemental_axe", {
	description = "Elemental Axe",
	inventory_image = "elemental_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.00, [2]=0.80, [3]=0.40}, uses=40, maxlevel=2},
		},
		damage_groups = {fleshy=8},
	},
})

minetest.register_craft({
	output = 'qt:elemental_axe',
	recipe = {
		{'qt:olmite_block', 'qt:farmite_block'},
		{'qt:farmite_block', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:elemental_axe',
	recipe = {'qt:elemental_axe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:elemental_sword", {
	description = "Elemental Sword",
	inventory_image = "elemental_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.80, [2]=0.80, [3]=0.20}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=10},
	}
})

minetest.register_craft({
	output = 'qt:elemental_sword',
	recipe = {
		{'qt:olmite_block'},
		{'qt:farmite_block'},
		{'group:stick'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:elemental_sword',
	recipe = {'qt:elemental_sword', 'qt_magic:magic_dust'},
})

-- Awesome Set
minetest.register_tool(":qt:awesome_pick", {
	description = "Awesome Pickaxe",
	inventory_image = "default_tool_diamondpick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.80, [2]=0.80, [3]=0.30}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
})

minetest.register_craft({
	output = 'qt:awesome_pick',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt:elemental_pick', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:awesome_pick',
	recipe = {'qt:awesome_pick', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:awesome_shovel", {
	description = "Awesome Shovel",
	inventory_image = "default_tool_diamondshovel.png",
	wield_image = "default_tool_diamondshovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=0.90, [2]=0.30, [3]=0.10}, uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
})

minetest.register_craft({
	output = 'qt:awesome_shovel',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt:elemental_shovel', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:awesome_shovel',
	recipe = {'qt:awesome_shovel', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:awesome_axe", {
	description = "Awesome Axe",
	inventory_image = "default_tool_diamondaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=1.90, [2]=0.70, [3]=0.30}, uses=50, maxlevel=2},
		},
		damage_groups = {fleshy=9},
	},
})

minetest.register_craft({
	output = 'qt:awesome_axe',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt:elemental_axe', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:awesome_axe',
	recipe = {'qt:awesome_axe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:awesome_sword", {
	description = "Awesome Sword",
	inventory_image = "default_tool_diamondsword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.70, [2]=0.70, [3]=0.10}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=11},
	}
})

minetest.register_craft({
	output = 'qt:awesome_sword',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'qt:elemental_sword', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:awesome_sword',
	recipe = {'qt:awesome_sword', 'qt_magic:magic_dust'},
})


--netherite set
minetest.register_craftitem(":qt:netherite_gem", {
	description = "Netherite Gem",
	inventory_image = "netherite_gem.png",
})

minetest.register_node(":qt:netherite_block", {
	description = "Netherite Block",
	tiles = {"netherite_block.png"},
	is_ground_content = false,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:netherite_gem',
	recipe = {
		{'', 'qt:fireflower', ''},
		{'qt:fireflower', 'default:diamond', 'qt:fireflower'},
		{'', 'qt:fireflower', ''},
	}
})

minetest.register_craft({
	output = 'qt:netherite_block',
	recipe = {
		{'qt:netherite_gem', 'qt:netherite_gem', 'qt:netherite_gem'},
		{'qt:netherite_gem', 'qt:netherite_gem', 'qt:netherite_gem'},
		{'qt:netherite_gem', 'qt:netherite_gem', 'qt:netherite_gem'},
	}
})

minetest.register_craft({
	output = 'qt:netherite_gem 9',
	recipe = {
		{'qt:netherite_block'},
	}
})

minetest.register_tool(":qt:netherite_pick", {
	description = "Netherite Pickaxe",
	inventory_image = "netherite_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.50, [2]=0.50, [3]=0.10}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=15},
	},
})

minetest.register_craft({
	output = 'qt:netherite_pick',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt:awesome_pick', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:netherite_pick',
	recipe = {'qt:netherite_pick', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:netherite_shovel", {
	description = "Netherite Shovel",
	inventory_image = "netherite_shovel.png",
	wield_image = "netherite_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=0.50, [2]=0.10, [3]=0.05}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=13},
	},
})

minetest.register_craft({
	output = 'qt:netherite_shovel',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt:awesome_shovel', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:netherite_shovel',
	recipe = {'qt:netherite_shovel', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:netherite_axe", {
	description = "Netherite Axe",
	inventory_image = "netherite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=1.50, [2]=0.30, [3]=0.10}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=15},
	},
})

minetest.register_craft({
	output = 'qt:netherite_axe',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt:awesome_axe', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:netherite_axe',
	recipe = {'qt:netherite_axe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:netherite_sword", {
	description = "Netherite Sword",
	inventory_image = "netherite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.30, [2]=0.30, [3]=0.05}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=16},
	}
})

minetest.register_craft({
	output = 'qt:netherite_sword',
	recipe = {
		{'', 'qt:netherite_gem', ''},
		{'qt:netherite_gem', 'qt:awesome_sword', 'qt:netherite_gem'},
		{'', 'qt:netherite_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:netherite_sword',
	recipe = {'qt:netherite_sword', 'qt_magic:magic_dust'},
})

--poison set

minetest.register_tool(":qt:poison_pick", {
	description = "Poison Pickaxe",
	inventory_image = "poison_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.00, [2]=0.30, [3]=0.05}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=19},
	},
})

minetest.register_craft({
	output = 'qt:poison_pick',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt:netherite_pick', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:poison_pick',
	recipe = {'qt:poison_pick', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:poison_shovel", {
	description = "Poison Shovel",
	inventory_image = "poison_shovel.png",
	wield_image = "poison_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=0.30, [2]=0.05, [3]=0.02}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=17},
	},
})

minetest.register_craft({
	output = 'qt:poison_shovel',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt:netherite_shovel', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:poison_shovel',
	recipe = {'qt:poison_shovel', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:poison_axe", {
	description = "Poison Axe",
	inventory_image = "poison_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=1.00, [2]=0.10, [3]=0.05}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=19},
	},
})

minetest.register_craft({
	output = 'qt:poison_axe',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt:netherite_axe', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:poison_axe',
	recipe = {'qt:poison_axe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:poison_sword", {
	description = "Poison Sword",
	inventory_image = "poison_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.90, [2]=0.10, [3]=0.02}, uses=80, maxlevel=3},
		},
		damage_groups = {fleshy=23},
	}
})

minetest.register_craft({
	output = 'qt:poison_sword',
	recipe = {
		{'', 'qt:poison_gem', ''},
		{'qt:poison_gem', 'qt:netherite_sword', 'qt:poison_gem'},
		{'', 'qt:poison_gem', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:poison_sword',
	recipe = {'qt:poison_sword', 'qt_magic:magic_dust'},
})

--murite set

minetest.register_tool(":qt:murite_pick", {
	description = "Murite Pickaxe",
	inventory_image = "murite_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.30, [2]=0.15, [3]=0.01}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=20},
	},
})

minetest.register_craft({
	output = 'qt:murite_pick',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt:poison_pick', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:murite_pick',
	recipe = {'qt:murite_pick', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:murite_shovel", {
	description = "Murite Shovel",
	inventory_image = "murite_shovel.png",
	wield_image = "murite_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=0.15, [2]=0.01, [3]=0.01}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=19},
	},
})

minetest.register_craft({
	output = 'qt:murite_shovel',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt:poison_shovel', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:murite_shovel',
	recipe = {'qt:murite_shovel', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:murite_axe", {
	description = "Murite Axe",
	inventory_image = "murite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=0.30, [2]=0.05, [3]=0.01}, uses=70, maxlevel=3},
		},
		damage_groups = {fleshy=20},
	},
})

minetest.register_craft({
	output = 'qt:murite_axe',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt:poison_axe', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:murite_axe',
	recipe = {'qt:murite_axe', 'qt_magic:magic_dust'},
})

minetest.register_tool(":qt:murite_sword", {
	description = "Murite Sword",
	inventory_image = "murite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.45, [2]=0.05, [3]=0.01}, uses=80, maxlevel=3},
		},
		damage_groups = {fleshy=26},
	}
})

minetest.register_craft({
	output = 'qt:murite_sword',
	recipe = {
		{'', 'qt:murite_crystal', ''},
		{'qt:murite_crystal', 'qt:poison_sword', 'qt:murite_crystal'},
		{'', 'qt:murite_crystal', ''},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:murite_sword',
	recipe = {'qt:murite_sword', 'qt_magic:magic_dust'},
})
