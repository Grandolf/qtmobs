minetest.register_craftitem(":qt:alloy_gold", {
	description = "14 Carrot Gold",
	inventory_image = "default_gold_ingot.png"
})

minetest.register_craftitem(":qt:gold_stick", {
	description = "Gold Stick",
	inventory_image = "stick.png",
})

minetest.register_craftitem(":qt:gold_plate", {
	description = "Gold Plate",
	inventory_image = "plate.png",
})

minetest.register_craftitem(":qt:gold_coal", {
	description = "Gold Coal",
	inventory_image = "coal.png"
})

minetest.register_craftitem(":qt:firegold", {
	description = "Firegold",
	inventory_image = "firegold.png"
})

minetest.register_craft({
	output = 'qt:firegold',
	recipe = {
		{'fire:basic_flame', 'fire:basic_flame', 'fire:basic_flame'},
		{'fire:basic_flame', 'default:gold_ingot', 'fire:basic_flame'},
		{'fire:basic_flame', 'fire:basic_flame', 'fire:basic_flame'},
	}
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:gold_coal",
	burntime = 1000,
})

minetest.register_node(":qt:gold_alloy_block", {
	description = "14 Carrot Gold Block",
	tiles = {"default_gold_block.png"},
	is_ground_content = true,
	groups = {cracky=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:gold_apple',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:apple', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "qt:gold_coal",
	recipe = {"default:gold_ingot", "default:coal_lump"},
})

minetest.register_craft({
	output = 'qt:gold_alloy_block',
	recipe = {
		{'qt:alloy_gold', 'qt:alloy_gold', 'qt:alloy_gold'},
		{'qt:alloy_gold', 'qt:alloy_gold', 'qt:alloy_gold'},
		{'qt:alloy_gold', 'qt:alloy_gold', 'qt:alloy_gold'},
	}
})

minetest.register_craft({
	output = 'qt:alloy_gold 9',
	recipe = {
		{'qt:gold_alloy_block'},
	}
})

minetest.register_craft({
	output = 'qt:gold_stick 3',
	recipe = {
		{'qt:alloy_gold'},
		{'qt:alloy_gold'},
		{'qt:alloy_gold'},
	}
})

minetest.register_craft({
	output = 'qt:gold_plate',
	recipe = {
		{'qt:alloy_gold', 'qt:alloy_gold'},
		{'qt:alloy_gold', 'qt:alloy_gold'},
	}
})

minetest.register_craft({
	output = 'qt:alloy_gold 4',
	recipe = {
		{'qt:gold_plate'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "qt:alloy_gold",
	recipe = {"default:gold_ingot", "default:copper_ingot"},
})

minetest.register_tool(":qt:gold_pick", {
	description = "Gold Pick",
	inventory_image = "pick.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			cracky = {times={[1]=4.00, [2]=1.60, [3]=0.80}, uses=20, maxlevel=2},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool(":qt:gold_shovel", {
	description = "Gold Shovel",
	inventory_image = "shovel.png",
	wield_image = "shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.1,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.50, [2]=0.90, [3]=0.40}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=3},
	},
})

minetest.register_tool(":qt:gold_axe", {
	description = "Gold Axe",
	inventory_image = "axe.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.50, [2]=1.40, [3]=1.00}, uses=20, maxlevel=2},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool(":qt:gold_sword", {
	description = "Gold Sword",
	inventory_image = "sword.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=2.5, [2]=1.20, [3]=0.35}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=6},
	}
})

minetest.register_craft({
	output = 'qt:gold_pick',
	recipe = {
		{'qt:alloy_gold', 'qt:alloy_gold', 'qt:alloy_gold'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:gold_shovel',
	recipe = {
		{'qt:alloy_gold'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:gold_axe',
	recipe = {
		{'qt:alloy_gold', 'qt:alloy_gold'},
		{'qt:alloy_gold', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:gold_sword',
	recipe = {
		{'qt:alloy_gold'},
		{'qt:alloy_gold'},
		{'group:stick'},
	}
})

minetest.register_tool(":qt:gold_septer", {
	description = "Golden Septer",
	inventory_image = "septer.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.50, [2]=0.90, [3]=0.40}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=8},
	},
})

minetest.register_craft({
	output = 'qt:gold_septer',
	recipe = {
		{'qt:alloy_gold'},
		{'qt:gold_stick'},
		{'qt:gold_stick'},
	}
})

minetest.register_node(":qt:gold_apple", {
	description = "Gold Apple",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"gold_apple.png"},
	inventory_image = "gold_apple.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = function(itemstack, user, pointed_thing)
		user:set_hp(user:get_hp()+10)
		itemstack:take_item(1)
		playereffects.apply_effect_type("regen", 30, user)
		return itemstack
	end,
	sounds = default.node_sound_leaves_defaults(),
	after_place_node = function(pos, placer, itemstack)
		if placer:is_player() then
			minetest.set_node(pos, {name="qt:gold_apple", param2=1})
		end
	end,
})


minetest.register_tool(":qt:firegold_sword", {
	description = "Firegold Flamesword",
	inventory_image = "firesword.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=0.13, [2]=0.08, [3]=0.01}, uses=60, maxlevel=3},
		},
		damage_groups = {fleshy=15},
	}
})


minetest.register_craft({
	output = 'qt:firegold_sword',
	recipe = {
		{'', 'qt:firegold', 'qt:nether_stone'},
		{'qt:firegold', 'qt:nether_stone', 'qt:firegold'},
		{'group:stick', 'qt:firegold', ''},
	}
})
