--qt_chests

minetest.register_craftitem(":qt:chest_bonus", {
	description = "Beginner's Bonus Chest",
	inventory_image = "chest.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node(pointed_thing.above, {name="default:chest"})
			local meta = minetest.get_meta(pointed_thing.above)
			local inv = meta:get_inventory()
			inv:set_size("main", 8*4)
			if not inv:contains_item("main", 1) then
				inv:set_stack("main", 1, "default:wood 33")
			end
			if not inv:contains_item("main", 2) then
				inv:set_stack("main", 2, "default:pick_stone")
			end
			if not inv:contains_item("main", 3) then
				inv:set_stack("main", 3, "default:shovel_stone")
			end
			if not inv:contains_item("main", 4) then
				inv:set_stack("main", 4, "default:axe_stone")
			end
			if not inv:contains_item("main", 5) then
				inv:set_stack("main", 5, "default:sword_stone")
			end
			if not inv:contains_item("main", 6) then
				inv:set_stack("main", 6, "default:torch 4")
			end
			if minetest.setting_getbool("creative_mode") ~= true then
				itemstack:take_item()
			end
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:chest_bonus',
	recipe = {
		{'', 'group:wood', ''},
		{'group:wood', 'default:chest', 'group:wood'},
		{'', 'group:wood', ''},
	}
})


minetest.register_craftitem(":qt:chest_miner", {
	description = "Mini Miner Chest",
	inventory_image = "chest.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node(pointed_thing.above, {name="default:chest"})
			local meta = minetest.get_meta(pointed_thing.above)
			local inv = meta:get_inventory()
			inv:set_size("main", 8*4)
			if not inv:contains_item("main", 1) then
				inv:set_stack("main", 1, "default:cobble 33")
			end
			if not inv:contains_item("main", 2) then
				inv:set_stack("main", 2, "default:pick_steel")
			end
			if not inv:contains_item("main", 3) then
				inv:set_stack("main", 3, "default:torch 33")
			end
			if minetest.setting_getbool("creative_mode") ~= true then
				itemstack:take_item()
			end
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = ':qt:chest_miner',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'group:stone', 'default:chest', 'group:stone'},
		{'group:stone', 'group:stone', 'group:stone'},
	}
})

minetest.register_craftitem(":qt:chest_viliger1", {
	description = "Viliger Surprise Chest",
	inventory_image = "chest.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node(pointed_thing.above, {name="default:chest"})
			local meta = minetest.get_meta(pointed_thing.above)
			local inv = meta:get_inventory()
			inv:set_size("main", 8*4)
			if not inv:contains_item("main", 1) then
				inv:set_stack("main", 1, "default:cobble 99")
			end
			if not inv:contains_item("main", 2) then
				inv:set_stack("main", 2, "default:wood 99")
			end
			if not inv:contains_item("main", 3) then
				inv:set_stack("main", 3, "default:torch 99")
			end
			if not inv:contains_item("main", 4) then
				inv:set_stack("main", 4, "default:pick_steel")
			end
			if not inv:contains_item("main", 5) then
				inv:set_stack("main", 5, "default:sword_steel")
			end
			if minetest.setting_getbool("creative_mode") ~= true then
				itemstack:take_item()
			end
		end
		return itemstack
	end,
})

minetest.register_craftitem(":qt:chest_royal", {
	description = "Royal Treasure Chest",
	inventory_image = "chest.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node(pointed_thing.above, {name="default:chest"})
			local meta = minetest.get_meta(pointed_thing.above)
			local inv = meta:get_inventory()
			inv:set_size("main", 8*4)
			if not inv:contains_item("main", 1) then
				inv:set_stack("main", 1, "default:mese_crystal 3")
			end
			if not inv:contains_item("main", 2) then
				inv:set_stack("main", 2, "default:diamond 3")
			end
			if not inv:contains_item("main", 3) then
				inv:set_stack("main", 3, "default:obsidian 9")
			end
			if not inv:contains_item("main", 4) then
				inv:set_stack("main", 4, "qt:gem_red 3")
			end
			if not inv:contains_item("main", 5) then
				inv:set_stack("main", 5, "qt:gem_blue 3")
			end
			if not inv:contains_item("main", 6) then
				inv:set_stack("main", 6, "qt:gem_green 3")
			end
			if not inv:contains_item("main", 7) then
				inv:set_stack("main", 7, "qt:gem_sky_blue 3")
			end
			if minetest.setting_getbool("creative_mode") ~= true then
				itemstack:take_item()
			end
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:chest_royal',
	recipe = {
		{'', 'default:diamond', ''},
		{'default:diamond', 'default:chest', 'default:diamond'},
		{'', 'default:diamond', ''},
	}
})
