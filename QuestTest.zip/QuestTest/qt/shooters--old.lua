--sdef.shootername
--sdef.is_shooter_tool (boolian val)
--sdef.tool_wear
--sdef.shooter_image
--sdef.shooter_def
--sdef.take_ammo (boolian value)
--sdef.ammo_name (seprately registered item, taken when shot)
--sdef.shoot_sound
--sdef.entity_name
--sdef.entity_image
--sdef.entity_weight
--sdef.entity_min_range
--sdef.damage (how much damage a entity receives of no special function)
--sdef.add_block
--sdef.block_to_add
--sdef.explode
--sdef.explode_radius
--sdef.remove_block
--sdef.explode_sound
--sdef.destory_terrain

minetest.register_node("qt:arrow_node", {
	tiles = {
		"arrow_top.png",
		"arrow_bottom.png",
		"arrow_back.png",
		"arrow_front.png",
		"arrow_side.png",
		"arrow_side_2.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.0625, -0.0625, 0.375, 0.0625, 0.0625}, -- NodeBox2
			{-0.375, -0.125, -0.0625, -0.25, 0.125, 0.0625}, -- NodeBox3
			{-0.375, -0.0625, -0.125, -0.25, 0.0625, 0.125}, -- NodeBox6
			{0.1875, 0.0625, 0, 0.5, 0.1875, 0.0625}, -- NodeBox7
			{0.1875, -0.1875, 0.0625, 0.5, -0.0625, 0.125}, -- NodeBox8
			{0.1875, -0.125, -0.1875, 0.5, -0.0625, -0.0625}, -- NodeBox9
		}
	}
})


qt.register_shooter({
	shootername = "qt:throwstick",
	is_shooter_tool = false,
	shooter_image = "default_stick.png",
	shooter_def = "Throwing Stick",
	take_ammo = true,
	ammo_name = "qt:throwstick",
	entity_name = "qt:throwstick_entity",
	entity_image = {"default_stick.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 1,
	visual = "sprite",
})

minetest.register_craftitem("qt:pebble", {
	description = "Pebble",
	inventory_image = "pebble.png",
	})

minetest.register_craftitem("qt:arrow", {
	description = "Arrow (basic bow ammo)",
	inventory_image = "arrow.png",
	})

minetest.register_craft({
	output = 'qt:pebble 9',
	recipe = {
		{'default:gravel'},
	}
})

minetest.register_craft({
	output = 'qt:arrow',
	recipe = {
		{'group:stick', 'group:stick', 'qt:pebble'},
	}
})

qt.register_shooter({
	shootername = "qt:bow_low",
	is_shooter_tool = true,
	tool_wear = 10000,
	shooter_image = "basic_bow.png",
	shooter_def = "Low Power Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:low_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 2,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_low',
	recipe = {
		{'', 'group:stick', 'farming:string'},
		{'group:stick', '', 'farming:string'},
		{'', 'group:stick', 'farming:string'},
	}
})

qt.register_shooter({
	shootername = "qt:bow_med",
	is_shooter_tool = true,
	tool_wear = 12500,
	shooter_image = "basic_bow.png",
	shooter_def = "Medium Power Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:med_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 9,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 4,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_med',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', '', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})

qt.register_shooter({
	shootername = "qt:bow_high",
	is_shooter_tool = true,
	tool_wear = 15000,
	shooter_image = "high_bow.png",
	shooter_def = "High Power Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:high_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 6,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_high',
	recipe = {
		{'group:wood', 'default:steel_ingot', 'farming:string'},
		{'default:steel_ingot', '', 'farming:string'},
		{'group:wood', 'default:steel_ingot', 'farming:string'},
	}
})

qt.register_shooter({
	shootername = "qt:bow_obsidian",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "obsidian_bow.png",
	shooter_def = "Obsidian Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:obsidian_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 7,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 9,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_obsidian',
	recipe = {
		{'', 'default:obsidian_shard', 'farming:string'},
		{'default:obsidian_shard', '', 'farming:string'},
		{'', 'default:obsidian_shard', 'farming:string'},
	}
})

local fire = true
if fire == true then
qt.register_shooter({
	shootername = "qt:bow_fire",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "fire_bow.png",
	shooter_def = "Fire Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:fire_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 10,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "fire:basic_flame"})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_fire',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'qt:farmite_powder', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end

local lava = true
if lava == true then
qt.register_shooter({
	shootername = "qt:bow_lava",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "lava_bow.png",
	shooter_def = "Lava Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:lava_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 12,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:lava_source"})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_lava',
	recipe = {
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:bow_fire', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
	}
})
end

local water = true
if water == true then
qt.register_shooter({
	shootername = "qt:bow_water",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "water_bow.png",
	shooter_def = "Water Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:water_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 8,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:water_source"})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_water',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'qt:olmite_powder', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end

local ice = true
if ice == true then
qt.register_shooter({
	shootername = "qt:bow_ice",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "ice_bow.png",
	shooter_def = "Ice Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:ice_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 10,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:ice"})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_ice',
	recipe = {
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:bow_water', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
	}
})
end

local sand = true
if sand == true then
qt.register_shooter({
	shootername = "qt:bow_sand",
	is_shooter_tool = true,
	tool_wear = 19000,
	shooter_image = "sand_bow.png",
	shooter_def = "Sand Bow",
	take_ammo = true,
	ammo_name = "qt:arrow",
	entity_name = "qt:sand_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 6,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:sand"})
		nodeupdate({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:bow_sand',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'default:sand', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end

qt.register_shooter({
	shootername = "qt:copper_throwing_star",
	is_shooter_tool = false,
	shooter_image = "copper_throwing_star.png",
	shooter_def = "Copper Throwing Star",
	take_ammo = true,
	ammo_name = "qt:copper_throwing_star",
	entity_name = "qt:copper_throwing_star_entity",
	entity_image = {"copper_throwing_star.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 4,
	visual = "sprite",
})


minetest.register_craft({
	output = 'qt:copper_throwing_star 11',
	recipe = {
		{'', 'default:copper_ingot', ''},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'', 'default:copper_ingot', ''},
	}
})

qt.register_shooter({
	shootername = "qt:gernade",
	is_shooter_tool = false,
	shooter_image = "gernade.png",
	shooter_def = "Gernade",
	take_ammo = true,
	ammo_name = "qt:gernade",
	entity_name = "qt:gernade_entity",
	entity_image = {"gernade.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 0,
	on_hit_entity = function(self, obj)
		qt.explode(self.object:getpos(), 4)
	end,
	on_hit_node = function(self, node)
		qt.explode(self.lastpos, 4)
	end,
	visual = "sprite",
})

minetest.register_craft({
	output = 'qt:gernade 9',
	recipe = {
		{'', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'tnt:tnt', 'default:steel_ingot'},
		{'', 'default:steel_ingot', ''},
	}
})

qt.register_shooter({
	shootername = "qt:gun_diamond",
	is_shooter_tool = true,
	tool_wear = 5000000,
	shooter_image = "diamond_gun.png",
	shooter_def = "Diamond Gun",
	take_ammo = true,
	ammo_name = "default:diamondblock",
	entity_name = "qt:diamond_gun_entity",
	entity_image = {"default:diamondblock"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 50,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:diamondblock"})
		nodeupdate({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z})
	end,
	visual = "wielditem",
})

minetest.register_craft({
	output = 'qt:gun_diamond',
	recipe = {
		{'default:diamondblock', 'default:diamondblock', 'default:diamond'},
		{'default:steel_ingot', 'default:diamond', ''},
		{'default:steel_ingot', 'default:wood', ''},
	}
})



minetest.register_node("qt:ruby_laser_shot_node", {
	tiles = {
		"ruby_laser_shot.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.0625, -0.0625, 10.625, 0.0625, 0.0625}, -- NodeBox1
		}
	}
})

minetest.register_craftitem("qt:ruby_laser_charge", {
	description = "Ruby Laser Charge",
	inventory_image = "ruby_laser_charge.png",
	})

qt.register_shooter({
	shootername = "qt:ruby_laser_gun",
	is_shooter_tool = true,
	tool_wear = 5000000,
	shooter_image = "ruby_laser_gun.png",
	shooter_def = "Ruby Laser Gun",
	take_ammo = true,
	ammo_name = "qt:ruby_laser_charge",
	entity_name = "qt:ruby_laser_gun_entity",
	entity_image = {"qt:ruby_laser_shot_node"},
	entity_weight = 0,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 25,
	visual = "wielditem",
	on_hit_node = function(self, node)
	--nil function to prevent item from being dropped
	end
})

minetest.register_craft({
	output = 'qt:ruby_laser_gun',
	recipe = {
		{'default:gold_ingot', 'qt:block_gem_red', 'qt:gem_red'},
		{'default:steel_ingot', 'default:gold_ingot', ''},
		{'default:steel_ingot', '', ''},
	}
})

minetest.register_craft({
	output = 'qt:ruby_laser_charge 11',
	recipe = {
		{'default:gold_ingot'},
		{'qt:gem_red'},
		{'default:gold_ingot'},
	}
})

