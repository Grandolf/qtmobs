

--entity to hold mobs in place
minetest.register_entity("qt:freezeing_entity", {
	physical = false,
	collisionbox = {0,0,0,0,0,0},
	visual = "sprite",
	textures = "invisible.png",
	visual_size = {x=0,  y=0},
	riding = nil,
	on_step = function(self, dtime)
		local selfpos = self.object:getpos()
		if self.riding ~= nil then
			self.riding:setpos(selfpos)
			self.riding:setacceleration({x=0, y=0, z=0})
			self.riding:setvelocity({x=0, y=0, z=0})
		end
		self.object:set_armor_groups({immortal = 1})
	end,
	set_riding = function(self, obj)
		self.riding = obj
	end,
})

local form_ice = function(pos)
	for y = pos.y-1, pos.y+1 do
		minetest.set_node({x=pos.x, y=y, z=pos.z}, {name = "default:ice"})
	end
end

qt.register_arrow({
	drop = "qt:aqumariene_ice_orb",
	entity_name = "qt:ice_orb_entity",
	entity_image = {"ice_orb.png"},
	entity_weight = 0,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 25,
	visual = "sprite",
	on_hit_node = function(self, node)
		form_ice(self.object:getpos())
	end,
	on_hit_entity = function(self, obja)
		form_ice(obja:getpos())
		if obja ~= nil then
		local mobpos = obja:getpos()
		local freezer = minetest.add_entity(mobpos, "qt:freezeing_entity")
		freezer:get_luaentity():set_riding(obja)
		minetest.after(10,  function(obja, freezer)
			if freezer:get_hp() ~= 0 or freezer:get_hp() ~= nil then
				--freezer:get_luaentity():set_riding(nil)
				freezer:remove()
			end
		end, obja, freezer)
		end
	end,
})

minetest.register_craftitem("qt:aqumariene_ice_orb", {
	description = "Ice Orb",
	inventory_image = "ice_orb.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:ice_orb_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:ice_orb_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:aqumariene_ice_orb 9',
	recipe = {
		{'', 'default:ice', ''},
		{'default:ice', 'qt:block_gem_sky_blue', 'default:ice'},
		{'', 'default:ice', ''},
	}
})
