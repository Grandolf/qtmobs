--qt

qt = {}
dofile(minetest.get_modpath("qt").."/legacy.lua")
dofile(minetest.get_modpath("qt").."/tnt_api.lua")
dofile(minetest.get_modpath("qt").."/api.lua")
dofile(minetest.get_modpath("qt").."/shooters.lua")
dofile(minetest.get_modpath("qt").."/freezer.lua")
dofile(minetest.get_modpath("qt").."/liquids.lua")
--tools:
--gem tools:
minetest.register_tool("qt:pick_blue_gem", {
	description = "Sapphire Pickaxe",
	inventory_image = "blue_gem_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_tool("qt:pick_green_gem", {
	description = "Emerald Pickaxe",
	inventory_image = "green_gem_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_tool("qt:pick_red_gem", {
	description = "Ruby Pickaxe",
	inventory_image = "red_gem_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})
minetest.register_tool("qt:pick_sky_blue_gem", {
	description = "Aqumarine Pickaxe",
	inventory_image = "sky_blue_gem_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=2.0, [2]=1.0, [3]=0.50}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_tool("qt:shovel_blue_gem", {
	description = "Sapphire Shovel",
	inventory_image = "blue_gem_shovel.png",
	wield_image = "blue_gem_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.10, [2]=0.50, [3]=0.30}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("qt:shovel_green_gem", {
	description = "Emerald Shovel",
	inventory_image = "green_gem_shovel.png",
	wield_image = "green_gem_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.10, [2]=0.50, [3]=0.30}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("qt:shovel_red_gem", {
	description = "Ruby Shovel",
	inventory_image = "red_gem_shovel.png",
	wield_image = "red_gem_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.10, [2]=0.50, [3]=0.30}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("qt:shovel_sky_blue_gem", {
	description = "Aqumarine Shovel",
	inventory_image = "sky_blue_gem_shovel.png",
	wield_image = "sky_blue_gem_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.10, [2]=0.50, [3]=0.30}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("qt:axe_blue_gem", {
	description = "Sapphire Axe",
	inventory_image = "blue_gem_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.10, [2]=0.90, [3]=0.50}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	},
})

minetest.register_tool("qt:axe_green_gem", {
	description = "Emerald Axe",
	inventory_image = "green_gem_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.10, [2]=0.90, [3]=0.50}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	},
})

minetest.register_tool("qt:axe_red_gem", {
	description = "Ruby Axe",
	inventory_image = "red_gem_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.10, [2]=0.90, [3]=0.50}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	},
})

minetest.register_tool("qt:axe_sky_blue_gem", {
	description = "Aqumarine Axe",
	inventory_image = "sky_blue_gem_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.10, [2]=0.90, [3]=0.50}, uses=30, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	},
})

minetest.register_tool("qt:sword_blue_gem", {
	description = "Sapphire Sword",
	inventory_image = "blue_gem_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.90, [2]=0.90, [3]=0.30}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	}
})

minetest.register_tool("qt:sword_green_gem", {
	description = "Emerald Sword",
	inventory_image = "green_gem_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.90, [2]=0.90, [3]=0.30}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	}
})

minetest.register_tool("qt:sword_red_gem", {
	description = "Ruby Sword",
	inventory_image = "red_gem_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.90, [2]=0.90, [3]=0.30}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	}
})

minetest.register_tool("qt:sword_sky_blue_gem", {
	description = "Aqumarine Sword",
	inventory_image = "sky_blue_gem_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.90, [2]=0.90, [3]=0.30}, uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	}
})
--obsidian tools:
minetest.register_tool("qt:pick_obsidian", {
	description = "Obsidian	Pickaxe",
	inventory_image = "obsidian_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=2.4, [2]=1.2, [3]=0.60}, uses=20, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
})

minetest.register_tool("qt:shovel_obsidian", {
	description = "Obsidian Shovel",
	inventory_image = "obsidian_shovel.png",
	wield_image = "obsidian_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=3,
		groupcaps={
			crumbly = {times={[1]=1.20, [2]=0.60, [3]=0.30}, uses=20, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
})

minetest.register_tool("qt:axe_obsidian", {
	description = "Obsidian Axe",
	inventory_image = "obsidian_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.20, [2]=1.00, [3]=0.60}, uses=20, maxlevel=3},
		},
		damage_groups = {fleshy=6},
	},
})

minetest.register_tool("qt:sword_obsidian", {
	description = "Obsidian Sword",
	inventory_image = "obsidian_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=2.0, [2]=1.00, [3]=0.35}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	}
})

--craftitems
minetest.register_craftitem("qt:gem_blue", {
	description = "Sapphire",
	inventory_image = "blue_gem.png",
})

minetest.register_craftitem("qt:gem_green", {
	description = "Emerald",
	inventory_image = "green_gem.png",
})

minetest.register_craftitem("qt:gem_red", {
	description = "Ruby",
	inventory_image = "red_gem.png",
})

minetest.register_craftitem("qt:gem_sky_blue", {
	description = "Aqumarine",
	inventory_image = "sky_blue_gem.png",
})

--minetest.register_craftitem("at:gunpowder", {
--	description = "Gunpowder",
--	inventory_image = "gunpowder.png",
--})

minetest.register_craftitem("qt:charcoal_lump", {
	description = "Charcoal Lump",
	inventory_image = "default_coal_lump.png",
})

minetest.register_craftitem("qt:farmite_powder", {
	description = "Farmite Powder",
	inventory_image = "farmite_powder.png",
})

minetest.register_craftitem("qt:olmite_powder", {
	description = "Olmite Powder",
	inventory_image = "olmite_powder.png",
})

minetest.register_craftitem("qt:corilium_ingot", {
	description = "Corilium Ingot",
	inventory_image = "corilium_ingot.png",
})

--nodes

minetest.register_node("qt:corilium_block", {
	description = "Corilium Block",
	tiles = {"corilium_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "qt:electrum"})
	end,
})

minetest.register_node("qt:electrum", {
	description = "Electrum",
	tiles = {"electrum.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_blue_gem", {
	description = "Sapphire Ore",
	tiles = {"default_stone.png^blue_gem_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:gem_blue",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_green_gem", {
	description = "Emerald Ore",
	tiles = {"default_stone.png^green_gem_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:gem_green",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_red_gem", {
	description = "Ruby Ore",
	tiles = {"default_stone.png^red_gem_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:gem_red",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_sky_blue_gem", {
	description = "Aqumarine Ore",
	tiles = {"default_stone.png^sky_blue_gem_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:gem_sky_blue",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:block_gem_blue", {
	description = "Sapphire Block",
	tiles = {"blue_gem_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:block_gem_green", {
	description = "Emerald Block",
	tiles = {"green_gem_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:block_gem_red", {
	description = "Ren Gem Block",
	tiles = {"red_gem_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:block_gem_sky_blue", {
	description = "Aqumarine Block",
	tiles = {"sky_blue_gem_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_farmite", {
	description = "Farmite Ore",
	tiles = {"default_stone.png^farmite_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:farmite_powder",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:stone_with_olmite", {
	description = "Olmite Ore",
	tiles = {"default_stone.png^olmite_ore.png"},
	is_ground_content = true,
	groups = {cracky=1},
	drop = "qt:olmite_powder",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:farmite_block", {
	description = "Farmite Block",
	tiles = {"farmite_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("qt:olmite_block", {
	description = "Olmite Block",
	tiles = {"olmite_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})
--Lamps
minetest.register_node("qt:lamp", {
	description = "Lamp",
	tiles = {"lamp.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_black", {
	description = "Black Lamp",
	tiles = {"lamp_black.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_blue", {
	description = "Blue Lamp",
	tiles = {"lamp_blue.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_brown", {
	description = "Brown Lamp",
	tiles = {"lamp_brown.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_cyan", {
	description = "Cyan Lamp",
	tiles = {"lamp_cyan.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_dark_green", {
	description = "Dark Green Lamp",
	tiles = {"lamp_dark_green.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_dark_grey", {
	description = "Dark Grey Lamp",
	tiles = {"lamp_dark_grey.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_green", {
	description = "Green Lamp",
	tiles = {"lamp_green.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_grey", {
	description = "Grey Lamp",
	tiles = {"lamp_grey.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_magenta", {
	description = "Magenta Lamp",
	tiles = {"lamp_magenta.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_orange", {
	description = "Orange Lamp",
	tiles = {"lamp_orange.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_pink", {
	description = "Pink Lamp",
	tiles = {"lamp_pink.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_red", {
	description = "Red Lamp",
	tiles = {"lamp_red.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_violet", {
	description = "Violet Lamp",
	tiles = {"lamp_violet.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_white", {
	description = "White Lamp",
	tiles = {"lamp_white.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

minetest.register_node("qt:lamp_yellow", {
	description = "Yellow Lamp",
	tiles = {"lamp_yellow.png"},
	drawtype = "glasslike",
	sunlight_propagates = true,
	is_ground_content = false,
	light_source = LIGHT_MAX-1,
	groups = {choppy=2,flammable=1,hot=2,lamp=1},
	sounds = default.node_sound_defaults(),
})

--ironstone & materials

minetest.register_node("qt:ironstone", {
	description = "Ironstone",
	tiles = {"ironstone.png"},
	is_ground_content = false,
	groups = {ironstone=1,undisruptable=1, antimagic=1},
	sounds = default.node_sound_stone_defaults(),
	on_blast = function(pos, intensity)
		--nil function to make explosion resestant
	end,
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "default:obsidian"})
	end,
})

minetest.register_tool("qt:ironstone_pick", {
	description = "IronStone Pickaxe",
	inventory_image = "ironstone_pick.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.40, [2]=0.30, [3]=0.10}, uses=30, maxlevel=3},
			ironstone = {times={[1]=25.0, [2]=20.0, [3]=15.0}, uses=30, maxlevel=3},
		},
		damage_groups = {fleshy=1},
	},
})

minetest.register_craftitem("qt:ironstone_shard", {
	description = "Ironstone Shard",
	inventory_image = "ironstone_chunk.png",
})

minetest.register_craft({
	output = 'qt:ironstone_pick',
	recipe = {
		{'qt:ironstone_shard', 'qt:ironstone_shard', 'qt:ironstone_shard'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:ironstone',
	recipe = {
		{'default:steel_ingot', 'default:gold_ingot', 'default:steel_ingot'},
		{'default:gold_ingot', 'default:obsidian', 'default:gold_ingot'},
		{'default:steel_ingot', 'default:gold_ingot', 'default:steel_ingot'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:ironstone_shard 4',
	recipe = {'qt:ironstone'},
})

--gunposder & explosives
--[[
tnt.boom(pos, def)

def.radius,
def.ignore_protection,
def.ignore_on_blast
def.disable_drops
def.damage_radius

tnt.boom(pos, {
	radius = ,
	ignore_protection = ,
	ignore_on_blast = ,
	disable_drops = ,
	damage_radius = ,
})

--]]
minetest.register_node("qt:gunpowder_block", {
	description = "Gunpowder Block",
	tiles = {"gunpowder_block.png"},
	is_ground_content = false,
	groups = {crumbly=3,},
	sounds = default.node_sound_dirt_defaults(),
	on_punch = function(pos, node, puncher, pointed_thing)
		local obj = puncher:get_wielded_item()
		if obj:get_name() == "default:torch" then
			qt.explode(pointed_thing.under, 6)
		end
	end,
	on_blast = function(pos, intensity)
		--qt.explode(pos, 6)
		tnt.boom(pos, {
			radius = 6,
			ignore_protection = false,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 1,
		})
	end,
	on_lightning_strike = function(pos, dist)
		tnt.boom(pos, {
			radius = 6,
			ignore_protection = false,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 1,
		})
	end,
})

minetest.register_abm({
	nodenames = {"qt:gunpowder_block"},
	neighbors = {"default:lava_source", "fire:basic_flame"},
	interval = 1,
	chance = 2,
	action = function(pos)
		tnt.boom(pos, {
			radius = 6,
			ignore_protection = false,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 1,
		})
	end,
})

-- fossil
minetest.register_craftitem("qt:fossil", {
	description = "Fossil",
	inventory_image = "fossil.png",
	groups = {bone=1},
})

--re-registering stone for fossil drop

minetest.override_item("default:stone", {
	description = "Stone",
	tiles = {"default_stone.png"},
	is_ground_content = true,
	groups = {cracky=3, stone=1},
	drop = {
		max_items = 1,
		items = {
			{
				items = {'qt:fossil'},
				rarity = 500,
			},
			{
				items = {'default:cobble'},
			}
		}
	},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

--polished stone
minetest.register_node("qt:polished_stone", {
	description = "Polished Stone",
	tiles = {"polished_stone.png"},
	groups = {cracky=3, stone=1},
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("polished_stone", "qt:polished_stone",
		{cracky = 3},
		{"polished_stone_slab.png"},
		"Polished Stone Stair",
		"Polished Stone Slab",
		default.node_sound_stone_defaults())

minetest.override_item("stairs:slab_polished_stone", {
	tiles = {"polished_stone.png","polished_stone.png","polished_stone_slab.png","polished_stone_slab.png","polished_stone_slab.png","polished_stone_slab.png" },
})

--mines

minetest.register_node(":qt:mine", {
	description = "Mine",
	tiles = {
		"default_grass.png",
		"black.png",
		"default_grass.png",
		"default_grass.png",
		"default_grass.png",
		"default_grass.png"
	},
	is_ground_content = false,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	on_walk = function(pos, player)
		tnt.boom(pos, {
			radius = 4,
			ignore_protection = false,
			ignore_on_blast = false,
			disable_drops = true,
			damage_radius = 3,
		})
	end,
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.3125, -0.5, 0.5, 0.5, 0.5}, -- NodeBox1
			{-0.0625, -0.5, -0.0625, 0.0625, 0.5625, 0.0625}, -- NodeBox2
		}
	}
})

minetest.register_craft({
	output = 'qt:mine',
	recipe = {
		{'qt:cobalt_ingot', 'default:dirt_with_grass', 'qt:cobalt_ingot'},
		{'', 'tnt:tnt', ''},
		{'', 'qt:cobalt_ingot', ''},
	}
})


--nodedef
--
--name = the node's name
--description = the node's description
--tiles = the images
--tiles.top, tiles. side, tiles.bottom = self explanatory

--entitydef
--name = the entity's name
--tiles = same as nodedef
--radius = the ecplosion radius
--timer = how long till the explosion
--[[
qt.register_tnt({
	name = "qt:gold_tnt",
	description = "Golden TNT",
	tiles = {top = "tnt_gold_top.png", bottom = "tnt_gold_bottom.png",side = "tnt_gold_side.png"},
}, {
	name = "qt:gold_tnt_entity",
	tiles = {top = "tnt_gold_top.png", bottom = "tnt_gold_bottom.png",side = "tnt_gold_side.png"},
	radius = 15,
	timer = 3,
})
--]]

tnt.register_tnt({
	name = "qt:gold_tnt",
	description = "Golden TNT",
	radius = 15,
	ignore_protection = false,
	ignore_on_blast = false,
	disable_drops = false,
	damage_radius = 1.5,
})

minetest.register_craft({
	output = 'qt:gold_tnt',
	recipe = {
		{'default:goldblock', 'default:goldblock','default:goldblock'},
		{'default:goldblock', 'tnt:tnt','default:goldblock'},
		{'default:goldblock', 'default:goldblock','default:goldblock'},
	}
})

minetest.register_node(":qt:natural_glass", {
	description = "Natural Glass",
	drawtype = "glasslike_framed_optional",
	tiles = {"natural_glass.png", "natural_glass_detail.png"},
	paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	sounds = default.node_sound_glass_defaults(),
	groups = {cracky=3,oddly_breakable_by_hand=3},
})

xpanes.register_pane("natural_pane", {
	description = "Natural Glass Pane",
	textures = {"natural_glass.png","natural_glass.png","natural_glass_side.png"},
	inventory_image = "natural_glass.png",
	wield_image = "natural_glass.png",
	sounds = default.node_sound_glass_defaults(),
	groups = {snappy=2, cracky=3, oddly_breakable_by_hand=3, pane=1},
	recipe = {
		{"qt:natural_glass", "qt:natural_glass", "qt:natural_glass"},
		{"qt:natural_glass", "qt:natural_glass", "qt:natural_glass"}
	}
})

minetest.override_item("default:sand", {
	description = "Sand",
	tiles = {"default_sand.png"},
	groups = {crumbly = 3, falling_node = 1, sand = 1},
	sounds = default.node_sound_sand_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "qt:natural_glass"})
	end,
})

minetest.override_item("default:desert_sand", {
	description = "Desert Sand",
	tiles = {"default_desert_sand.png"},
	groups = {crumbly = 3, falling_node = 1, sand = 1},
	sounds = default.node_sound_sand_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "qt:natural_glass"})
	end,
})


--ore generation:
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_blue_gem",
	wherein        = "default:stone",
	clust_scarcity = 17*17*17,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -255,
	y_max     = -128,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_blue_gem",
	wherein        = "default:stone",
	clust_scarcity = 15*15*15,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -31000,
	y_max     = -256,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_green_gem",
	wherein        = "default:stone",
	clust_scarcity = 17*17*17,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -255,
	y_max     = -128,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_green_gem",
	wherein        = "default:stone",
	clust_scarcity = 15*15*15,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -31000,
	y_max     = -256,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_red_gem",
	wherein        = "default:stone",
	clust_scarcity = 17*17*17,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -255,
	y_max     = -128,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_red_gem",
	wherein        = "default:stone",
	clust_scarcity = 15*15*15,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -31000,
	y_max     = -256,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_sky_blue_gem",
	wherein        = "default:stone",
	clust_scarcity = 17*17*17,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -255,
	y_max     = -128,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_sky_blue_gem",
	wherein        = "default:stone",
	clust_scarcity = 15*15*15,
	clust_num_ores = 4,
	clust_size     = 3,
	y_min     = -31000,
	y_max     = -256,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_farmite",
	wherein        = "default:stone",
	clust_scarcity = 7*7*7,
	clust_num_ores = 10,
	clust_size     = 10,
	y_min     = -200,
	y_max     = -120,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "qt:stone_with_olmite",
	wherein        = "default:stone",
	clust_scarcity = 7*7*7,
	clust_num_ores = 10,
	clust_size     = 10,
	y_min     = -200,
	y_max     = -120,
	flags          = "absheight",
})

--increase gold spawning

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "default:stone_with_gold",
	wherein        = "default:stone",
	clust_scarcity = 15*15*15,
	clust_num_ores = 3,
	clust_size     = 2,
	y_min     = -255,
	y_max     = -64,
	flags          = "absheight",
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "default:stone_with_gold",
	wherein        = "default:stone",
	clust_scarcity = 13*13*13,
	clust_num_ores = 5,
	clust_size     = 3,
	y_min     = -31000,
	y_max     = -256,
	flags          = "absheight",
})

--crafting
minetest.register_craft({
	output = 'qt:pick_blue_gem',
	recipe = {
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:pick_red_gem',
	recipe = {
		{'qt:gem_red', 'qt:gem_red', 'qt:gem_red'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:pick_green_gem',
	recipe = {
		{'qt:gem_green', 'qt:gem_green', 'qt:gem_green'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:pick_sky_blue_gem',
	recipe = {
		{'qt:gem_sky_blue', 'qt:gem_sky_blue', 'qt:gem_sky_blue'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:pick_obsidian',
	recipe = {
		{'default:obsidian', 'default:obsidian', 'default:obsidian'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'qt:shovel_blue_gem',
	recipe = {
		{'qt:gem_blue'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:shovel_green_gem',
	recipe = {
		{'qt:gem_green'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:shovel_red_gem',
	recipe = {
		{'qt:gem_red'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:shovel_sky_blue_gem',
	recipe = {
		{'qt:gem_sky_blue'},
		{'group:stick'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:shovel_obsidian',
	recipe = {
		{'default:obsidian'},
		{'group:stick'},
		{'group:stick'},
	}
})


minetest.register_craft({
	output = 'qt:axe_blue_gem',
	recipe = {
		{'qt:gem_blue', 'qt:gem_blue'},
		{'qt:gem_blue', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:axe_green_gem',
	recipe = {
		{'qt:gem_green', 'qt:gem_green'},
		{'qt:gem_green', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:axe_red_gem',
	recipe = {
		{'qt:gem_red', 'qt:gem_red'},
		{'qt:gem_red', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:axe_sky_blue_gem',
	recipe = {
		{'qt:gem_sky_blue', 'qt:gem_sky_blue'},
		{'qt:gem_sky_blue', 'group:stick'},
		{'', 'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:axe_obsidian',
	recipe = {
		{'default:obsidian', 'default:obsidian'},
		{'default:obsidian', 'group:stick'},
		{'', 'group:stick'},
	}
})
minetest.register_craft({
	output = 'qt:sword_blue_gem',
	recipe = {
		{'qt:gem_blue'},
		{'qt:gem_blue'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:sword_green_gem',
	recipe = {
		{'qt:gem_green'},
		{'qt:gem_green'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:sword_red_gem',
	recipe = {
		{'qt:gem_red'},
		{'qt:gem_red'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:sword_sky_blue_gem',
	recipe = {
		{'qt:gem_sky_blue'},
		{'qt:gem_sky_blue'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:sword_obsidian',
	recipe = {
		{'default:obsidian'},
		{'default:obsidian'},
		{'group:stick'},
	}
})

minetest.register_craft({
	output = 'qt:corilium_block',
	recipe = {
		{'qt:corilium_ingot', 'qt:corilium_ingot', 'qt:corilium_ingot'},
		{'qt:corilium_ingot', 'qt:corilium_ingot', 'qt:corilium_ingot'},
		{'qt:corilium_ingot', 'qt:corilium_ingot', 'qt:corilium_ingot'},
	}
})

minetest.register_craft({
	output = 'qt:block_gem_blue',
	recipe = {
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
		{'qt:gem_blue', 'qt:gem_blue', 'qt:gem_blue'},
	}
})

minetest.register_craft({
	output = 'qt:block_gem_green',
	recipe = {
		{'qt:gem_green', 'qt:gem_green', 'qt:gem_green'},
		{'qt:gem_green', 'qt:gem_green', 'qt:gem_green'},
		{'qt:gem_green', 'qt:gem_green', 'qt:gem_green'},
	}
})

minetest.register_craft({
	output = 'qt:block_gem_red',
	recipe = {
		{'qt:gem_red', 'qt:gem_red', 'qt:gem_red'},
		{'qt:gem_red', 'qt:gem_red', 'qt:gem_red'},
		{'qt:gem_red', 'qt:gem_red', 'qt:gem_red'},
	}
})

minetest.register_craft({
	output = 'qt:block_gem_sky_blue',
	recipe = {
		{'qt:gem_sky_blue', 'qt:gem_sky_blue', 'qt:gem_sky_blue'},
		{'qt:gem_sky_blue', 'qt:gem_sky_blue', 'qt:gem_sky_blue'},
		{'qt:gem_sky_blue', 'qt:gem_sky_blue', 'qt:gem_sky_blue'},
	}
})

minetest.register_craft({
	output = 'qt:farmite_block',
	recipe = {
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
	}
})

minetest.register_craft({
	output = 'qt:olmite_block',
	recipe = {
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
	}
})

minetest.register_craft({
	output = 'qt:corilium_ingot 9',
	recipe = {
		{'qt:corilium_block'},
	}
})

minetest.register_craft({
	output = 'qt:gem_blue 9',
	recipe = {
		{'qt:block_gem_blue'},
	}
})

minetest.register_craft({
	output = 'qt:gem_green 9',
	recipe = {
		{'qt:block_gem_green'},
	}
})

minetest.register_craft({
	output = 'qt:gem_red 9',
	recipe = {
		{'qt:block_gem_red'},
	}
})

minetest.register_craft({
	output = 'qt:gem_sky_blue 9',
	recipe = {
		{'qt:block_gem_sky_blue'},
	}
})

minetest.register_craft({
	output = 'qt:farmite_powder 9',
	recipe = {
		{'qt:farmite_block'},
	}
})

minetest.register_craft({
	output = 'qt:olmite_powder 9',
	recipe = {
		{'qt:olmite_block'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_black',
	recipe = {'group:lamp', 'group:unicolor_black'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_blue',
	recipe = {'group:lamp', 'group:unicolor_blue'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_brown',
	recipe = {'group:lamp', 'group:unicolor_dark_orange'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_cyan',
	recipe = {'group:lamp', 'group:unicolor_cyan'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_dark_green',
	recipe = {'group:lamp', 'group:unicolor_dark_green'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_dark_grey',
	recipe = {'group:lamp', 'group:unicolor_darkgrey'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_green',
	recipe = {'group:lamp', 'group:unicolor_green'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_grey',
	recipe = {'group:lamp', 'group:unicolor_grey'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_magenta',
	recipe = {'group:lamp', 'group:unicolor_red_violet'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_orange',
	recipe = {'group:lamp', 'group:unicolor_orange'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_pink',
	recipe = {'group:lamp', 'group:unicolor_light_red'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_red',
	recipe = {'group:lamp', 'group:unicolor_red'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_violet',
	recipe = {'group:lamp', 'group:unicolor_violet'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_white',
	recipe = {'group:lamp', 'group:unicolor_white'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:lamp_yellow',
	recipe = {'group:lamp', 'group:unicolor_yellow'},
})

minetest.register_craft({
	output = 'qt:lamp',
	recipe = {
		{'default:stick', 'default:glass', 'default:stick'},
		{'default:glass', 'default:torch', 'default:glass'},
		{'default:stick', 'default:glass', 'default:stick'},
	}
})

minetest.register_craft({
	output = 'default:torch 4',
	recipe = {
		{'qt:charcoal_lump'},
		{'group:stick'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:charcoal_lump",
	recipe = "group:wood",
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:charcoal_lump",
	burntime = 40,
})
--tnt:gunpowder
--minetest.register_craft({
--	type = "shapeless",
--	output = "at:gunpowder 2",
--	recipe = {"at:charcoal_lump", "default:coal_lump"},
--})

--minetest.register_craft({
--	output = 'at:gunpowder_block',
--	recipe = {
--		{'at:gunpowder', 'at:gunpowder', 'at:gunpowder'},
--		{'at:gunpowder', 'at:gunpowder', 'at:gunpowder'},
--		{'at:gunpowder', 'at:gunpowder', 'at:gunpowder'},
--	}
--})

minetest.register_craft({
	type = "shapeless",
	output = "tnt:gunpowder 2",
	recipe = {"qt:charcoal_lump", "default:gravel"},
})

minetest.register_craft({
	output = 'qt:gunpowder_block',
	recipe = {
		{'tnt:gunpowder', 'tnt:gunpowder', 'tnt:gunpowder'},
		{'tnt:gunpowder', 'tnt:gunpowder', 'tnt:gunpowder'},
		{'tnt:gunpowder', 'tnt:gunpowder', 'tnt:gunpowder'},
	}
})

--minetest.register_craft({
--	type = "shapeless",
--	output = "at:gunpowder 9",
--	recipe = {"at:gunpowder_block"},
--})

minetest.register_craft({
	type = "shapeless",
	output = "tnt:gunpowder 9",
	recipe = {"qt:gunpowder_block"},
})

--minetest.register_craft({
--	output = 'at:tnt',
--	recipe = {
--		{'default:paper', 'farming:string', 'default:paper'},
--		{'default:paper', 'at:gunpowder_block', 'default:paper'},
--		{'default:paper', 'default:paper', 'default:paper'},
--	}
--})

minetest.register_craft({
	output = 'farming:string',
	recipe = {
		{'farming:cotton'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "qt:polished_stone",
	recipe = {"default:stone"},
})

minetest.register_craft({
	type = "cooking",
	output = "default:lava_source",
	recipe = "default:stone",
})

--this is down here to be able to use the items registered in this file
dofile(minetest.get_modpath("qt").."/specialtools.lua")
